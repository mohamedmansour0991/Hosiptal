<?php

namespace App\Exports;

use App\Models\building;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\FromArray;

class BuildingExport implements FromArray, WithHeadings , ShouldAutoSize , WithStyles
{

    public function array(): array
    {
        $list = [];
        $buildings = building::all();
        foreach($buildings as $building){
            $list[]= [
                'Name' => $building->name,
                'Image' => $building->image,
            ];
        }
        return $list ;
    }
    public function headings(): array
    {
        return [
            'Building Name',
            'Building Image',
        ];
    }
    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1    => ['font' => ['bold' => true, 'size' => 16, 'italic' => true]],
        ];
    }

}
