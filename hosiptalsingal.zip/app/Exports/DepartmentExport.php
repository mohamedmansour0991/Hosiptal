<?php

namespace App\Exports;

use App\Models\department;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\FromArray;

class DepartmentExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{

    public function array(): array
    {
        $list = [];
        $departments = department::all();
        foreach ($departments as $department) {
            $list[] = [
                'Name' => $department->name,
                'Level Name' => $department->level->name,
                'Building Name' => $department->build->name,
            ];
        }
        return $list;
}


    public function headings(): array
    {
        return [
            'Department Name',
            'Level Name',
            'Building Name',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1    => ['font' => ['bold' => true, 'size' => 16, 'italic' => true
            ]],
        ];
    }
}
