<?php

namespace App\Exports;

use App\Models\item;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\FromArray;

class ItemExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{
    public function array(): array
    {
        $list = [];
        $items = item::all();
        foreach ($items as $item) {
            $list[] = [
                'name' => $item->name,
                'image' => $item->image,
                'group_category' => $item->group_category,
                'group' => $item->group,
                'quantity' => $item->quantity,
                'transfer' => $item->transfer,
                'requirement_qty' => $item->requirement_qty,
                'unit_cost' => $item->unit_cost,
                'total_cost' => $item->total_cost,
                'comments' => $item->comments,
                'general_specs' => $item->general_specs,
                'detailed_spec_document' => $item->detailed_spec_document,
                'revit_model' => $item->revit_model,
                'code_model' => $item->code_model,
                'Bim_id' => $item->Bim_id,
                'electrical' => $item->electrical,
                'data' => $item->data,
                'o2' => $item->o2,
                'air' => $item->air,
                'tool_air' => $item->tool_air,
                'vaccum' => $item->vaccum,
                'agss' => $item->agss,
                'water' => $item->water,
                'drain' => $item->drain,
                'steam' => $item->steam,
                'mounting' => $item->mounting,
                'weight' => $item->weight,
                'dimension' => $item->dimension,
                'indicatir' => $item->indicatir,
                'contact_name' => $item->contact_name,
                'contact_number' => $item->contact_number,
                // 'room_id' => $item->room_id,
                // 'dept_id' => $item->dept_id,
                // 'Level Name' => $item->level_id,
                // 'Building Name' => $item->build_id,
                'room_id' => $item->room->name,
                'dept_id' => $item->dept->name,
                'Level Name' => $item->level->name,
                'Building Name' => $item->build->name,
            ];
        }
        return $list;
    }

    public function headings(): array
    {
        return [
            'Item name',
            'Item image',
            'Item group_category',
            'Item group',
            'Item quantity',
            'Item transfer',
            'Item requirement_qty',
            'Item unit_cost',
            'Item total_cost',
            'Item comments',
            'Item general_specs',
            'Item detailed_spec_document',
            'Item revit_model',
            'Item code_model',
            'Item Bim_id',
            'Item electrical',
            'Item Data',
            'Item o2',
            'Item air',
            'Item tool_air',
            'Item vaccum',
            'Item agss',
            'Item water',
            'Item drain',
            'Item steam',
            'Item mounting',
            'Item weight',
            'Item dimension',
            'Item indicatir',
            'Item contact_name',
            'Item contact_number',
            'Room Name',
            'Department Name',
            'Level Name',
            'Building Name',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1    => ['font' => ['bold' => true, 'size' => 16, 'italic' => true]],
        ];
    }
}
