<?php

namespace App\Exports;

use App\Models\level;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
class LevelExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function array(): array
    {
        $list = [];
        $levels = level::all();
        foreach ($levels as $level) {
            $list[] = [
                'Name' => $level->name,
                'Building Name' => $level->build->name,
            ];
        }
        return $list;
    }

    public function headings(): array
    {
        return [
            'Level Name',
            'Building Name',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1    => ['font' => ['bold' => true, 'size' => 16, 'italic' => true]],
        ];
    }
}
