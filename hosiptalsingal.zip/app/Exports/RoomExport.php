<?php

namespace App\Exports;

use App\Models\room;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\FromArray;

class RoomExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{

    public function array(): array
    {
        $list = [];
        $rooms = room::all();
        foreach ($rooms as $room) {
            $list[] = [
                'Code' => $room->code,
                'Name' => $room->name,
                'Image' => $room->image,
                'DepartMent Name' => $room->dept->name,
                'Level Name' => $room->level->name,
                'Building Name' => $room->build->name,
            ];
        }
        return $list;
    }

    public function headings(): array
    {
        return [
            'Room Code',
            'Room Name',
            'Room Image',
            'Department Name',
            'Level Name',
            'Building Name',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1    => ['font' => ['bold' => true, 'size' => 16, 'italic' => true]],
        ];
    }

    
}
