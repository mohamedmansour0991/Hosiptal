<?php

namespace App\Http\Controllers;

use App\helpers\UploadImage;
use App\Models\building;
use Illuminate\Routing\Controller;
use App\Http\Requests\StorePostRequest;

class BuildingControoler extends Controller
{

    public function index()
    {
        $buildings = building::get();
        return view('building.index', compact('buildings'));
    }


    public function create()
    {
        return view('building.create');
    }


    public function store(StorePostRequest $request)
    {
        try {
            $path = UploadImage::UploadImage($request ,'build');
            building::create([
                'name'=> $request->name,
                'image' => $path,
            ]);
            return redirect()->back()->with('success', 'Data saved successfully');
            
            
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function show($id)
    {
        $building = building::findorFail($id);
        return view('building.show', compact('building'));
    }


    public function edit($id)
    {
        $building = building::findorFail($id);
        return view('building.edit', compact('building'));
    }


    public function update(StorePostRequest $request, $id)
    {

        try {
            $building = building::findorFail($id);

            $path = UploadImage::UploadImage($request ,'build');
            $building->update([
                'name' => $request->name,
                'image' => $path,
            ]);

            return redirect()->back()->with('edit', 'Data Updated successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function destroy($id)
    {
        try {

            building::destroy($id);
            return redirect()->back()->with('delete', 'Data has been deleted successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
