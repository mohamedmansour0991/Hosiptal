<?php

namespace App\Http\Controllers;

use App\Http\Requests\DepartmentRequest;
use App\Models\department;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Http\Requests\StorePostRequest;
use App\Models\building;
use App\Models\level;
use App\Models\room;

class DepartmentControoler extends Controller
{

    public function index()
    {
        $departments = department::get();
        return view('department.index', compact('departments'));
    }


    public function create()
    {
        $builds = building::get();
        $rooms = room::get();
        return view('department.create', compact( 'builds', 'rooms'));
    }


    public function store(DepartmentRequest $request)
    {
        try {
            // $build = building::findOrFail($request->build_id) ;
            // $build->department()->create($request->all());
            $dept = new department();
            $dept->name = $request->name;
            $dept->build_id = $request->build_id;
            $dept->level_id = $request->level_id;
            $dept->save();
            $request->session()->flash('success', 'Data saved successfully');
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function show(StorePostRequest $post)
    {
        //
    }


    public function edit($id)
    {
        $department = department::findorFail($id);
        $builds = building::get();
        $levels = level::where('build_id',$department->build_id)->get();
        return view('department.edit', compact('department', 'builds', 'levels'));
    }


    public function update(DepartmentRequest $request, $id)
    {

        try {
            $dept = department::findorFail($id);

            // $department->update($request->all());
            
            $dept->name = $request->name;
            $dept->build_id = $request->build_id;
            $dept->level_id = $request->level_id;
            $dept->update();

            return redirect()->back()->with('edit', 'Data Updated successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function destroy($id)
    {
        try {

            department::destroy($id);
            return redirect()->back()->with('delete', 'Data has been deleted successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
