<?php

namespace App\Http\Controllers;

use App\Models\item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DownloadFileController extends Controller
{
    public function download1($id){
        $items = item::where('id',$id)->get();
foreach($items as $item)
        // return Storage::download(storage_path("app/files" .'/'. $item->detailed_spec_document), "Detailed_spec_document" );
        return Storage::download("app/public/files/
        
           
        kkk
        
        -+{$item->detailed_spec_document}", "1Detailed_spec_document");
        // return $item->detailed_spec_document ; 
    }
}
