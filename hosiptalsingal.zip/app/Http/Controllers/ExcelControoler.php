<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Exports\BuildingExport;
use App\Exports\DepartmentExport;
use App\Exports\ItemExport;
use App\Exports\LevelExport;
use App\Exports\RoomExport;
use Illuminate\Routing\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\ImportExcelRequest;
use App\Imports\BuildingImport;
use App\Imports\DepartmentImport;
use App\Imports\ItemImport;
use App\Imports\LevelImport;
use App\Imports\RoomImport;

class ExcelControoler extends Controller
{
    public function export()
    {
        return Excel::download(new BuildingExport, 'building.xlsx');
    }

    public function exportLevel()
    {
        return Excel::download(new LevelExport, 'level.xlsx');
    }
    public function exportDepartment()
    {
        return Excel::download(new DepartmentExport, 'Department.xlsx');
    }
    public function exportRoom()
    {
        return Excel::download(new RoomExport, 'Room.xlsx');
    }
    public function exportItem()
    {
        return Excel::download(new ItemExport, 'Item.xlsx');
    }
    
    public function show()
    {
        return view('extracts.importExcel');
    }
    public function importLevelFile ()
    {
        return view('extracts.importlevel');
    }
    public function importDepartmentFile()
    {
        return view('extracts.importDepartment');
    }
    public function importRoomFile()
    {
        return view('extracts.importRoom');
    }
    public function importItemFile()
    {
        return view('extracts.importItem');
    }
    
    
    public function import(Request $request)
    {
        try {
            Excel::import(new BuildingImport, $request->file('file')->store('filesBuildingExcel'));
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function importLevel(Request $request)
    {
        try {
            Excel::import(new LevelImport, $request->file('file')->store('filesLevelExcel'));
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
    public function importDepartment(Request $request)
    {
        try {
            Excel::import(new DepartmentImport, $request->file('file')->store('filesDepartmentExcel'));
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
    public function importRoom(Request $request)
    {
        try {
            Excel::import(new RoomImport, $request->file('file')->store('filesRoomExcel'));
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
    
    public function importItem(Request $request)
    {
        try {
            Excel::import(new ItemImport, $request->file('file')->store('filesItemExcel'));
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
