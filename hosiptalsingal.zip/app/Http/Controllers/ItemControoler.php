<?php

namespace App\Http\Controllers;

use App\Models\item;
use App\Models\room;
use App\Models\level;
use App\Models\building;
use App\Models\department;
use App\Http\Requests\ItemRequest;
use Illuminate\Routing\Controller;
use App\helpers\UploadImage;

class ItemControoler extends Controller
{

    public function index()
    {
        $items = item::get();
        return view('item.index', compact('items'));
    }


    public function create()
    {
        $builds = building::get();
        return view('item.create',compact('builds'));
    }


    public function store(ItemRequest $request)
    {
        try {
            $path = UploadImage::UploadImageItem($request, 'Item_image');
            $path_detailed_spec_document = UploadImage::UploadFileItem($request, 'detailed_spec_document' ,'detailed_spec_document');
            $path_revit_model = UploadImage::UploadFileItem($request, 'revit_model','revit_model');
            $path_code_model = UploadImage::UploadFileItem($request, 'code_model','code_model');

            $item = new item();
            $requirement_qty = (abs($request->quantity- $request->transfer));
            $total_cost =$requirement_qty* $request->unit_cost;
            $item->name = $request->name;
            $item->image = $path;
            $item->detailed_spec_document = $path_detailed_spec_document;
            $item->revit_model = $path_revit_model;
            $item->code_model = $path_code_model;
            $item->group_category = $request->group_category;
            $item->group = $request->group;
            $item->quantity = $request->quantity;
            $item->transfer = $request->transfer;
            $item->requirement_qty = $requirement_qty;
            $item->unit_cost = $request->unit_cost;
            $item->total_cost = $total_cost;
            $item->comments = $request->comments;
            $item->general_specs = $request->general_specs;
            $item->Bim_id = $request->Bim_id;
            $item->electrical = $request->electrical;
            $item->data = $request->data;
            $item->o2 = $request->o2;
            $item->air = $request->air;
            $item->tool_air = $request->tool_air;
            $item->vaccum = $request->vaccum;
            $item->agss = $request->agss;
            $item->water = $request->water;
            $item->drain = $request->drain;
            $item->steam = $request->steam;
            $item->mounting = $request->mounting;
            $item->weight = $request->weight;
            $item->dimension = $request->dimension;
            $item->comment_after_edit = $request->comment_after_edit;
            $item->indicatir = $request->indicatir;
            $item->contact_name = $request->contact_name;
            $item->contact_number = $request->contact_number;
            $item->build_id = $request->build_id;
            $item->level_id = $request->level_id;
            $item->room_id  = $request->room_id;
            $item->dept_id  = $request->dept_id;
            $item->save();
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function show(ItemRequest $post)
    {
        //
    }


    public function edit($id)
    {
        $item = item::findorFail($id);
        $builds = building::get();
        $levels = level::get();
        $rooms = room::get();
        $departments = department::get();
        return view('item.edit', compact('item', 'builds', 'levels', 'rooms', 'departments'));
    }


    public function update(ItemRequest $request, $id)
    {

        try {
            $path = UploadImage::UploadImageItem($request, 'Item_image');
            $path_detailed_spec_document = UploadImage::UploadFileItem($request, 'detailed_spec_document', 'detailed_spec_document');
            $path_revit_model = UploadImage::UploadFileItem($request, 'revit_model', 'revit_model');
            $path_code_model = UploadImage::UploadFileItem($request, 'code_model', 'code_model');

            $item =item::findorFail($id);
            $requirement_qty = ($request->quantity - $request->transfer) * -1;
            $total_cost = $requirement_qty * $request->unit_cost;
            $item->name = $request->name;
            $item->image = $path;
            $item->detailed_spec_document = $path_detailed_spec_document;
            $item->revit_model = $path_revit_model;
            $item->code_model = $path_code_model;
            $item->group_category = $request->group_category;
            $item->group = $request->group;
            $item->quantity = $request->quantity;
            $item->transfer = $request->transfer;
            $item->requirement_qty = $requirement_qty;
            $item->unit_cost = $request->unit_cost;
            $item->total_cost = $total_cost;
            $item->comments = $request->comments;
            $item->general_specs = $request->general_specs;
            $item->Bim_id = $request->Bim_id;
            $item->electrical = $request->electrical;
            $item->data = $request->data;
            $item->o2 = $request->o2;
            $item->air = $request->air;
            $item->tool_air = $request->tool_air;
            $item->vaccum = $request->vaccum;
            $item->agss = $request->agss;
            $item->water = $request->water;
            $item->drain = $request->drain;
            $item->steam = $request->steam;
            $item->mounting = $request->mounting;
            $item->weight = $request->weight;
            $item->dimension = $request->dimension;
            $item->comment_after_edit = $request->comment_after_edit;
            $item->indicatir = $request->indicatir;
            $item->contact_name = $request->contact_name;
            $item->contact_number = $request->contact_number;
            $item->build_id = $request->build_id;
            $item->level_id = $request->level_id;
            $item->room_id  = $request->room_id;
            $item->dept_id  = $request->dept_id;
            $item->comment_after_edit = $request->comment_after_edit;

            $item->update();

            return redirect()->back()->with('edit', 'Data Updated successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function destroy($id)
    {
        try {

            item::destroy($id);
            return redirect()->back()->with('delete', 'Data has been deleted successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
