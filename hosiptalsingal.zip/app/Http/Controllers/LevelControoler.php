<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\LevelRequest;
use App\Models\building;
use App\Models\level;

class LevelControoler extends Controller
{

    public function index()
    {
        $levels = level::get();
        return view('levels.index', compact('levels'));
    }


    public function create()
    {
        $builds = building::get();

    
        return view('levels.create',compact('builds'));
    }


    public function store(LevelRequest $request)
    {
        try {
            $build = building::findOrFail($request->build_id);
            $build->level()->create($request->all());
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function show(level $level)
    {
        //
    }


    public function edit($id)
    {
        $level = level::findorFail($id);

        $builds = building::get();

        return view('levels.edit', compact('level', 'builds'));
    }


    public function update(LevelRequest $request, $id)
    {

        try {
            $level = level::findorFail($id);

            $level->update($request->all());

            return redirect()->back()->with('edit', 'Data Updated successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function destroy($id)
    {
        try {

            level::destroy($id);
            return redirect()->back()->with('delete', 'Data has been deleted successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
