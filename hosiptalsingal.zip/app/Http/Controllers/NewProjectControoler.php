<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use Illuminate\Http\Request;

class NewProjectControoler extends Controller
{
    public function index(Request $request)
    {
        if ($request->email == "admin@gmail.com" && $request->password == 12345678) {
            $tenants = Tenant::orderBy('created_at', 'asc')->get();
            return view('tenacys', compact('tenants'));
        }
        return redirect()->back()->withErrors('sory not allow ');
    }
}
