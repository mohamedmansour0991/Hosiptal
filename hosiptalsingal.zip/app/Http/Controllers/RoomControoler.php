<?php

namespace App\Http\Controllers;

use App\Models\room;
use App\Models\level;
use App\Models\building;
use App\helpers\UploadImage;
use App\Http\Requests\RoomRequest;
use Illuminate\Routing\Controller;

class RoomControoler extends Controller
{

    public function index()
    {
        $rooms = room::get();
        return view('room.index', compact('rooms'));
    }


    public function create()
    {
        $builds = building::get();
        $levels = level::get();
        return view('room.create', compact('builds', 'levels'));
    }


    public function store(RoomRequest $request)
    {
        try {

            $path = UploadImage::UploadImageRoom($request, 'room_image');
            $room = new room();
            $room->name = $request->name;
            $room->code = $request->code;
            $room->image = $path;
            $room->build_id = $request->build_id;
            $room->level_id = $request->level_id;
            $room->dept_id = $request->dept_id;
            $room->save();
            return redirect()->back()->with('success', 'Data saved successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function show($id)
    {
        $room = room::findorFail($id);
        return view('room.show', compact('room'));
    }


    public function edit($id)
    {
        $room = room::findorFail($id);
        $builds = building::get();
        $levels = level::get();
        $depts = level::get();
        return view('room.edit', compact('room', 'builds', 'levels', 'depts'));
    }


    public function update(RoomRequest $request, $id)
    {

        try {
            $path = UploadImage::UploadImageRoom($request, 'room_image');
            $room = room::findorFail($id);
            $room->name = $request->name;
            $room->code = $request->code;
            $room->image = $path;
            $room->build_id = $request->build_id;
            $room->level_id = $request->level_id;
            $room->dept_id = $request->dept_id;
            $room->update();

            return redirect()->back()->with('edit', 'Data Updated successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }


    public function destroy($id)
    {
        try {

            room::destroy($id);
            return redirect()->back()->with('delete', 'Data has been deleted successfully');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
