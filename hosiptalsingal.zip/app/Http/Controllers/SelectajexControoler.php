<?php

namespace App\Http\Controllers;

use App\Models\room;
use App\Models\level;
use Illuminate\Http\Request;
use App\Http\Requests\DepartmentRequest;
use App\Models\department;
use App\Models\item;

class SelectajexControoler extends Controller
{
    public function  fetchRoom($build_id = null)
    {
        $levels = level::where('build_id', $build_id)->get();
        return response()->json([
            'status' => 1,
            'states' => $levels
        ]);
        // return $rooms ; 
    }
    public function  fetchItemRoom($level_id = null)
    {
        $items = room::where('level_id', $level_id)->get();
        return response()->json([
            'status' => 1,
            'rooms' => $items
        ]);
        // return $rooms ; 
    }

    public function  fetchLevel($build_id = null)
    {
        $levels = level::where('build_id', $build_id)->get();
        return response()->json([
            'status' => 1,
            'states' => $levels
        ]);
        // return $rooms ; 
    }
    
    public function  fetchItem($build_id = null)
    {
        $items = level::where('build_id', $build_id)->get();
        return response()->json([
            'status' => 1,
            'states' => $items
        ]);
        // return $rooms ; 
    }
 
    

    public function fetchdept($level_id = null)
    {
        $dept = department::where('level_id', $level_id)->get();
        return response()->json([
            'status' => 1,
            'depts' => $dept
        ]);
        // return $rooms ; 
    }


    public function  fetchItemRoomDepartment($dept_id = null)
    {
        $items = room::where('dept_id', $dept_id)->get();
        return response()->json([
            'status' => 1,
            'departments' => $items
        ]);
        // return $rooms ; 
    }
}
