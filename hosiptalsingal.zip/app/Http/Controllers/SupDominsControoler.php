<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SupDominsControoler extends Controller
{
    public function store(Request $request){
     $tenant1 = Tenant::create(['id' => $request->subdomain]);
     $tenant1->domains()->create(['domain' => $request->subdomain .'.localhost']);
        return redirect()->back()->with('success', 'Data saved successfully');
    }
}
