<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\User;

class UserController extends Controller
{
    public function admin($id)
    {
        $user = User::find($id);
        if ($user->status == 1) {
            $user->admin = 1;
        } else {
            $user->admin = 0;
        }

        $user->save();
        return redirect()->back();
    }
    public function notadmin($id)
    {
        $user = User::find($id);

        if ($user->admin == 2) {
            $user->admin = 2;
        } else {
            $user->admin = 0;
        }


        $user->save();
        return redirect()->back();
    }
    public function ban($id)
    {
        $user = User::find($id);
        if ($user->admin == 2 ) {
            $user->status = 1;
        } else {
            $user->status = 0;
        }

        $user->save();
        return redirect()->back();
    }
    public function unban($id)
    {
        $user = User::find($id);
        $user->status = 1; 
        $user->save();
        return redirect()->back();
    }
    public function accept($id)
    {
        $user = User::find($id);
        $user->status = 1;
        $user->save();
        return redirect()->back();
    }
}
