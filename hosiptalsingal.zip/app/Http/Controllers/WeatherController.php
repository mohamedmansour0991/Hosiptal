<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider;

class WeatherController extends Controller
{
    public function login(LoginRequest $request)
    {
        try { {
                $request->authenticate();
                $users = User::all();
                $request->session()->regenerate();
                return redirect()->route('dashboard.index')->with('success', 'Data saved successfully');
            }
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    public function create(Request $request)
    {
        try {

            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);

            return view('auth.login');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    
    public function logout()
    {
        auth()->logout();
        return redirect()->route('user.login')->with('success', 'logout successfully');
    }
}
