<?php

namespace App\Http\Controllers;

use App\Models\level;
use App\Models\building;
use App\Models\item;
use App\Models\room;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class pdfControoler extends Controller
{
    public function pdfBuilding()
    {
        $buildings = building::paginate(5);
        return view('pdf.buildingPdf',compact('buildings'));
    }

    public function pdfBuildingCovert()
    {
        $buildings = building::all();
        $customPaper = array(0, 0, 820, 1040);
        $pdf = PDF::loadView('pdf.buildingPdf', compact('buildings'))->setPaper($customPaper, 'landscape');
        return $pdf->download('building.pdf');
    }
    public function pdfItem()
    {
        $items = item::paginate(5);
        return view('pdf.itemPdf', compact('items'));
    }

    public function pdfItemCovert()
    {
        $items = item::paginate(5);
        $customPaper = array(0, 0, 820, 1040);
        $pdf = PDF::loadView('pdf.itemPdf', compact('items'))->setPaper($customPaper, 'landscape');
        return $pdf->download('item.pdf');
    }
    public function pdfRoom()
    {
        $rooms = room::all();
        $items = item::all();
        return view('pdf.room', compact('rooms', 'items'));
    }

    public function pdfRoomCovert()
    {
        $rooms = room::all();
        $items = item::all();
        $customPaper = array(0, 0, 820, 1040);
        $pdf = PDF::loadView('pdf.room', compact('rooms','items'))->setPaper($customPaper, 'landscape');
        return $pdf->download('room.pdf');
    }
}
