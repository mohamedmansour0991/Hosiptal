<?php

namespace App\helpers;

use Exception;
use Illuminate\Http\Request;
use App\Http\Requests\ItemRequest;
use App\Http\Requests\RoomRequest;
use App\Http\Requests\StorePostRequest;
use App\Http\Requests\ImportExcelRequest;

class UploadImage
{
    public static function UploadImage(StorePostRequest $request, $folderName)
    {
        $image = $request->file('image')->getClientOriginalName();
        $path = $request->file('image')->storeAs($folderName, $image, 'corner');
        return $path;
    }

    public static function UploadImageRoom(RoomRequest $request, $folderName)
    {
        $image = $request->file('image')->getClientOriginalName();
        $path = $request->file('image')->storeAs($folderName, $image, 'corner');
        return $path;
    }

    public static function UploadImageItem(ItemRequest $request, $folderName)
    {
        $image = $request->file('image')->getClientOriginalName();
        $path = $request->file('image')->storeAs($folderName, $image, 'corner');
        return $path;
    }
    public static function UploadFileItem(ItemRequest $request,$file, $folderName)
    {
        $image = $request->file($file)->getClientOriginalName();
        $path = $request->file($file)->storeAs($folderName, $image, 'corner');
        return $path;
    }
    public static function ImportExcel(ImportExcelRequest $request,  $folderName)
    {
        $image = $request->file('file')->getClientOriginalName();
        $path = $request->file('file')->storeAs($folderName, $image, 'corner');
        return $path;
    }
}
