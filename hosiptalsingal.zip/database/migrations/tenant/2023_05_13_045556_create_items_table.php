<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('items', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('image');
            $table->integer('group_category');
            $table->integer('group');
            $table->integer('quantity');
            $table->integer('transfer');
            $table->integer('requirement_qty');
            $table->integer('unit_cost');
            $table->integer('total_cost');
            $table->text('comments')->nullable();
            $table->string('general_specs');
            $table->text('detailed_spec_document');
            $table->string('revit_model');
            $table->string('code_model');
            $table->string('Bim_id');
            $table->string('electrical');
            $table->string('data');
            $table->string('o2');
            $table->string('air');
            $table->string('tool_air');
            $table->string('vaccum');
            $table->string('agss');
            $table->string('water');
            $table->string('drain');
            $table->string('steam');
            $table->string('mounting');
            $table->string('weight');
            $table->string('dimension');
            $table->string('comment_after_edit')->nullable();
            $table->string('indicatir');
            $table->string('contact_name');
            $table->string('contact_number');


            $table->foreignId('room_id')->constrained('rooms')->cascadeOnDelete();
            $table->foreignId('dept_id')->constrained('departments')->cascadeOnDelete();
            $table->foreignId('level_id')->constrained('levels')->cascadeOnDelete();
            $table->foreignId('build_id')->constrained('buildings')->cascadeOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('items');
    }
};
