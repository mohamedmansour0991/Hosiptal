@extends('layouts.master')

@section('title')
    Corner Edge| Group
@endsection

@section('content')
    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Buildings List</h6>

                    <button type="button" class="btn btn-success m-2"><a style="color: white"
                            href="{{ route('buildings.create') }}">Add Building</a></button>
                </div>


                <div class="btn-group" role="group" style=" margin-bottom: 13px;" aria-label="Basic example">
                    <button type="button" class="btn btn-primary"><a style="color: white"
                            href="{{ route('export.excel') }}">Export Excel
                        </a></button>
                    <button type="button" class="btn btn-success"><a style="color: white"
                            href="{{ route('show.excel') }}">Import Excel </a></button>
                    <button type="button" class="btn btn-danger"><a style="color: white"
                            href="{{ route('pdf.building.covert') }}">Pdf</a></button>
                </div>

                @if (session()->has('delete'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('delete') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif
            @endif

            <div class="table-responsive">
                <table id="DataTables_Table_0" class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            {{-- <th scope="col"><input class="form-check-input" type="checkbox"></th> --}}
                            <th scope="col">#</th>
                            @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                <th scope="col">Building code</th>
                            @endif

                            <th scope="col">Building Name </th>
                            <th scope="col">Created_at</th>
                            <th scope="col">updated_at</th>
                            <th scope="col">Image</th>
                            @if (Auth::user()->admin != 0)
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                            <th scope="col">Details</th>
                              @endif
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($buildings as $building)
                            <tr>
                                
                                <td>{{ $loop->iteration }}</td>
                                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                    <td>{{ $building->id }}</td>
                                @endif

                                <td>{{ $building->name }}</td>
                                <td>{{ $building->created_at }}</td>
                                <td>{{ $building->updated_at }}</td>
                                <td><img src="{{url('images').'/'.$building->image}} "
                                        style=" height:100px; width: 150PX; " class="img-fluid rounded-start"
                                        alt="Building Image Not Found"></td>
                                @if (Auth::user()->admin != 0)
                                    <td>
                                        <a href="{{ route('buildings.edit', $building->id) }}"
                                            class="btn btn-primary rounded-pill m-2" role="button" type="button"
                                            aria-disabled="true">Edit</a>
                                    </td>
                                    <td>

                                        <button type="button"class="btn btn-danger rounded-pill m-2" data-toggle="modal"
                                            data-target="#delete_post{{ $building->id }}">Delete</button>
                                    </td>
                                    <td>

                                        <a href="{{ route('buildings.show', $building->id) }}" type="button"
                                            class="btn btn-success rounded-pill m-2" role="button"
                                            aria-disabled="true">Details</a>
                                    </td>
                                @endif
                            </tr>

                            @include('building.destroy')
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Recent Sales End -->
@endsection
