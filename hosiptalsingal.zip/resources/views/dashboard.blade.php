@extends('layouts.master')
@section('title')
    Corner Edge| Group
@endsection

@section('content')
    @foreach ($users as $user)
    @endforeach
    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Cost</p>
                        <h6 class="mb-0">{{ \App\Models\item::sum('total_cost') }} £E</h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-bar fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Item Requir</p>
                        <h6 class="mb-0">{{ \App\Models\item::count('requirement_qty') }} </h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-area fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2"> Item Transfer</p>
                        <h6 class="mb-0">{{ \App\Models\item::count('transfer') }} </h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-pie fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Building</p>
                        <h6 class="mb-0">{{ \App\Models\building::count() }} </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Sale & Revenue End -->

    @if (Auth::user()->admin != 0)
        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Recent Salse</h6>
                    <p style="color: red">User Paid <span style="color: rgb(226, 13, 13)">(
                            {{ \App\Models\User::where('status', 2)->count() }} )</span> </p>
                </div>

                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                {{-- <th scope="col"><input class="form-check-input" type="checkbox"></th> --}}
                                <th scope="col">User Name</th>
                                <th scope="col">User Email</th>
                                <th scope="col">User Type</th>
                                <th scope="col">Status</th>
                                @if ($user->admin == 2 )
                                    <th scope="col">Action</th>
                                @endif

                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                                <tr>

                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>
                                        @if ($user->admin == 0)
                                            <span style="color: green">User</span>
                                        @elseif ($user->admin == 1)
                                            <span style="color: rgb(171, 207, 39)">Admin</span>
                                        @else
                                            <span style="color:gold">Super Admin</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if ($user->status == 2)
                                            <span style="color: rgb(39, 207, 199)">Paid</span>
                                        @elseif ($user->status == 1)
                                            <span style="color: green">Active</span>
                                        @else
                                            <span style="color: red">Block</span>
                                        @endif
                                    </td>
                                    <td>

                                        @if ($user->status == 2)
                                            <button class="btn btn-sm btn-success"
                                                onclick="window.location='{{ url("users/accept/$user->id") }}'">Accept</button>
                                        @endif
                                        @if (Auth::user()->admin == 2)
                                            @if ($user->admin == 0)
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="window.location='{{ url("users/admin/$user->id") }}'">Admin</button>
                                            @else
                                                <button class="btn btn-sm btn-primary"
                                                    onclick="window.location='{{ url("users/notadmin/$user->id") }}'">UnAdmin</button>
                                            @endif
                                            @if ($user->status == 1)
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="window.location='{{ url("users/ban/$user->id") }}'">Block</button>
                                            @else
                                                <button class="btn btn-sm btn-success"
                                                    onclick="window.location='{{ url("users/unban/$user->id") }}'">UnBlock</button>
                                            @endif
                                        @endif
                                    </td>
                                </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Recent Sales End -->
    @endif

    <!-- Widgets Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-8 col-xl-8">
                <div class="h-100 bg-light rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <h6 class="mb-0">Project Managers</h6>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="asset/img/user.jpg" alt=""
                            style="width: 40px; height: 40px;">
                        <div class="w-100 ms-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-0">Jhon Doe</h6>
                                <a href="" class="btn btn-success  " role="button" type="button"
                                    aria-disabled="true">WhatsApp</a>
                            </div>
                            <span>Short message goes here...</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="asset/img/user.jpg" alt=""
                            style="width: 40px; height: 40px;">
                        <div class="w-100 ms-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-0">Jhon Doe</h6>
                                <a href="" class="btn btn-success  " role="button" type="button"
                                    aria-disabled="true">WhatsApp</a>
                            </div>
                            <span>Short message goes here...</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="asset/img/user.jpg" alt=""
                            style="width: 40px; height: 40px;">
                        <div class="w-100 ms-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-0">Jhon Doe</h6>
                                <a href="" class="btn btn-success  " role="button" type="button"
                                    aria-disabled="true">WhatsApp</a>
                            </div>
                            <span>Short message goes here...</span>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-xl-4">
                <div class="h-100 bg-light rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Calender</h6>
                        <a href="">Show All</a>
                    </div>
                    <div id="calender"></div>
                </div>
            </div>

        </div>
    </div>
    <!-- Widgets End -->
@endsection
