        @extends('layouts.master')

        <!-- Content Header (Page header) -->


        <!-- Main content -->

        @section('content')

            <form style="    margin-top: 150px;width: 90%;margin-bottom: 315px;margin-left: 27px;"
                action="{{ route('import.room') }}" method="POST" enctype="multipart/form-data">
                @csrf
                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif


                @if (session()->has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('success') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif
                <div class="form-group">
                    <label for="exampleInputEmail1">Import File</label>
                    <input type="file" name="file" class="form-control" required>
                </div>
                <div class="card-footer">
                    <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                </div>
            </form>

        @endsection
