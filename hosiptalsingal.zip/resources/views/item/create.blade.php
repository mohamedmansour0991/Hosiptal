@extends('layouts.master')


@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 100%;margin-top: 50px;">

            <!-- Default box -->


            <div class="card-body">

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif


                @if (session()->has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('success') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Add New Item</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="{{ route('items.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Name</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Group Category</label>
                                <input type="text" name="group_category" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Group</label>
                                <input type="text" name="group" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Quantity</label>
                                <input type="text" name="quantity" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Transfer</label>
                                <input type="text" name="transfer" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Unit Cost</label>
                                <input type="text" name="unit_cost" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Data</label>
                                <input type="text" name="data" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">General Specs</label>
                                <input type="text" name="general_specs" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Bim Id </label>
                                <input type="text" name="Bim_id" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mounting</label>
                                <input type="text" name="mounting" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Weight</label>
                                <input type="text" name="weight" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Dimension</label>
                                <input type="text" name="dimension" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Indicatir</label>
                                <input type="text" name="indicatir" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Contact Name</label>
                                <input type="text" name="contact_name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Contact Number</label>
                                <input type="text" name="contact_number" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Comments</label>
                                <input type="text" name="comments" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Image</label>
                                <input type="file" name="image" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Detailed Specs Document</label>
                                <input type="file" name="detailed_spec_document" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Revit Model</label>
                                <input type="file" name="revit_model" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Code Model</label>
                                <input type="file" name="code_model" class="form-control" required>
                            </div>


                            <div class="form-group">
                                <label for="build_item">Building Name</label>
                                <select id="build_item" name="build_id" class="form-control" required>
                                    <option selected <option selected>Choose Building</option>

                                    @forelse ($builds as $build)
                                        <option value="{{ $build->id }}">{{ $build->name }}</option>
                                    @empty
                                        <option value="" class="text-warning">No Building Found!</option>
                                    @endforelse

                                </select>
                            </div>

                            <div class="form-group">
                                <label for="level_item">Level Name</label>
                                <select id="level_item" name="level_id" class="form-control" required>
                                    <option selected>Choose Level</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="dept_item">Deprtment Name</label>
                                <select id="dept_item" name="dept_id" class="form-control" required>
                                    <option selected>Choose Deprtment</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="room_item">Room Name</label>
                                <select id="room_item" name="room_id" class="form-control" required>
                                    <option selected>Choose Room</option>
                                </select>
                            </div>


                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Electrical</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="electrical"
                                            id="gridRadios1" value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="electrical"
                                            id="gridRadios2" value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">O2</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="o2" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="o2" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>


                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Air</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="air" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="air" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Tool Air</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="tool_air" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="tool_air" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Vaccum</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="vaccum" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="vaccum" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Agss</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="agss" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="agss" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Water</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="water" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="water" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Drain</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="drain" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="drain" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Steam</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="steam" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="steam" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
    </div>
    <!-- /.card -->

    </section>
    <!-- /.content -->


    <!-- /.content-wrapper -->

@endsection
