@extends('layouts.master')

@section('title')
    Corner Edge| Group
@endsection

@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->

        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0"> Items List</h6>

                        <button type="button" class="btn btn-success m-2"><a style="color: white"
                                href="{{ route('items.create') }}">Add Item </a></button>
                    </div>
                    <div class="btn-group" role="group" style=" margin-bottom: 13px;" aria-label="Basic example">
                        <button type="button" class="btn btn-primary"><a style="color: white"
                                href="{{ route('export.excel.item') }}">Export Excel
                            </a></button>
                        <button type="button" class="btn btn-success"><a style="color: white"
                                href="{{ route('import.item.File.excel') }}">Import Excel </a></button>
                        <button type="button" class="btn btn-danger"><a style="color: white"
                                href="{{ route('pdf.item.covert') }}">Pdf </a></button>
                    </div>

                    @if (session()->has('delete'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i>
                            {{ \session()->get('delete') }}
                            <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                            </button>
                        </div>
                    @endif
                @endif
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">

                        <thead>
                            <tr class="text-dark">
                                <th scope="col">#</th>
                                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                    <th scope="col">Item Code </th>
                                @endif
                                <th scope="col">Item_Name </th>
                                <th scope="col">Item_Group Category</th>
                                <th scope="col">Item_Group </th>
                                <th scope="col">Item Quantity </th>
                                <th scope="col">Item Transfer </th>
                                <th scope="col">Unit Cost</th>
                                <th scope="col">Requirement Quantity </th>
                                <th scope="col">Total_Cost </th>
                                <th scope="col">Bim Id</th>
                                <th scope="col">Data </th>
                                <th scope="col">General_Specs </th>
                                <th scope="col">Electrical </th>
                                <th scope="col">O2</th>
                                <th scope="col">Air </th>
                                <th scope="col">Tool_Air</th>
                                <th scope="col">vaccum</th>
                                <th scope="col">Agss </th>
                                <th scope="col">water </th>
                                <th scope="col">Drain </th>
                                <th scope="col">Steam</th>
                                <th scope="col">Mounting </th>
                                <th scope="col">Weight </th>
                                <th scope="col">Dimension </th>
                                <th scope="col">Indicatir</th>
                                <th scope="col">Contact Name </th>
                                <th scope="col">Contact Number </th>
                                <th scope="col">Room Name</th>
                                <th scope="col">Department Name </th>
                                <th scope="col">Level Name </th>
                                <th scope="col">Building Name </th>
                                <th scope="col">Comment </th>
                                <th scope="col">Created_at</th>
                                <th scope="col">updated_at</th>
                                <th scope="col">_Item_Image_ </th>
                                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                    <th scope="col">Comment_After_Edit </th>
                                    <th scope="col">detailed Spec Documen </th>
                                    <th scope="col">Revit Model </th>
                                    <th scope="col">Code Model </th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                    <th scope="col">Details</th>
                                @endif

                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($items as $item)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                        <td>{{ $item->id }}</td>
                                    @endif
                                    <td>{{ $item->name }}</td>
                                    <td>{{ $item->group_category }}</td>
                                    <td>{{ $item->group }}</td>
                                    <td>{{ $item->quantity }}</td>
                                    <td>{{ $item->transfer }}</td>
                                    <td>{{ $item->unit_cost }}</td>
                                    <td>{{ $item->requirement_qty }}</td>
                                    <td>{{ $item->total_cost }} £E</td>
                                    <td>{{ $item->Bim_id }}</td>
                                    <td>{{ $item->data }}</td>
                                    <td>{{ $item->general_specs }}</td>
                                    <td>{{ $item->electrical }}</td>
                                    <td>{{ $item->o2 }}</td>
                                    <td>{{ $item->air }}</td>
                                    <td>{{ $item->tool_air }}</td>
                                    <td>{{ $item->vaccum }}</td>
                                    <td>{{ $item->agss }}</td>
                                    <td>{{ $item->water }}</td>
                                    <td>{{ $item->drain }}</td>
                                    <td>{{ $item->steam }}</td>
                                    <td>{{ $item->mounting }}</td>
                                    <td>{{ $item->weight }}</td>
                                    <td>{{ $item->dimension }}</td>
                                    <td>{{ $item->indicatir }}</td>
                                    <td>{{ $item->contact_name }}</td>
                                    <td>{{ $item->contact_number }}</td>
                                    <td>{{ $item->room_id }}</td>
                                    <td>{{ $item->dept_id }}</td>
                                    <td>{{ $item->level_id }}</td>
                                    <td>{{ $item->build_id }}</td>
                                    <td>{{ $item->comments }}</td>
                                    <td>{{ $item->created_at }}</td>
                                    <td>{{ $item->updated_at }}</td>
                                    <td><img src="images{{url(''). '/'. $item->image }} "
                                            style=" height:100px; width: 150PX; " class="img-fluid rounded-start"
                                            alt="Item Image Not Found"></td>
                                    @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                        <td>{{ $item->comment_after_edit }}</td>
                                        <td>
                                            <a href="{{ route('download1.file', $item->id) }}"
                                                class="btn btn-success rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true"><i class="fa fa-download "></i></a>
                                        </td>
                                        <td>
                                            <a href="{{ route('items.edit', $item->id) }}"
                                                class="btn btn-success rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true"><i class="fa fa-download "></i></a>
                                        </td>
                                        <td>
                                            <a href="{{ route('items.edit', $item->id) }}"
                                                class="btn btn-success rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true"><i class="fa fa-download "></i></a>
                                        </td>
                                        <td>
                                            <a href="{{ route('items.edit', $item->id) }}"
                                                class="btn btn-primary rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true">Edit</a>
                                        </td>
                                        <td>
                                            <button type="button"class="btn btn-danger rounded-pill m-2"
                                                data-toggle="modal"
                                                data-target="#delete_post{{ $item->id }}">Delete</button>
                                        </td>
                                        <td>
                                            <a href="{{ route('items.show', $item->id) }}" type="button"
                                                class="btn btn-success rounded-pill m-2" role="button"
                                                aria-disabled="true">Details</a>
                                        </td>
                                    @endif
                                </tr>
                                @include('item.destroy')
                            @endforeach
                    </table>
                </div>
            </div>
            <!-- /.card -->

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
    @endsection
