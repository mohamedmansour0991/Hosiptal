

<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-light navbar-light">
        <a href=" {{ route('dashboard.index') }}" class="navbar-brand mx-4 mb-3">
            <h3 class="text-primary"> <img src="{{ url('logo.jpg ') }} " alt=" Logo"
                    class="brand-image img-circle elevation-3"
                    style="border-radius: 50%;opacity: .8;width: 50px; margin-right: 5px; ">Corner
                Edge</h3>
        </a>
        <div class="d-flex align-items-center ms-4 mb-4">
            <div class="position-relative">
                <img class="rounded-circle" src="{{ url('avatar.png') }}" alt=""
                    style="width: 40px; height: 40px;">
                <div
                    class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1">
                </div>
            </div>
            <div class="ms-3">
                <h6 class="mb-0">{{ Auth::user()->name }}</h6>
                <span>

                        @if (Auth::user()->admin == 0)
                            <span style="color: green">User</span>
                        @elseif (Auth::user()->admin == 1)
                            
                            <span style="color: rgb(171, 207, 39)">Admin</span>
                        @else
                            
                            <span style="color:gold">Super Admin</span>
                        @endif
                </span>
            </div>
        </div>
        <div class="navbar-nav w-100">
            <a href=" {{ route('dashboard.index') }}" class="nav-item nav-link active"><i
                    class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
            <a href="{{ route('buildings.index') }}" class="nav-item nav-link"><i class="fa fa-home me-2"></i>
                Buildings
                <span style="color:#f90808 " class="badge badge-info right">{{ \App\Models\building::count() }}</span>
            </a>
            <a href="{{ route('levels.index') }}" class="nav-item nav-link"><i class="fa fa-th me-2"></i>
                Levels
                <span style="color:#f90808 "class="badge badge-info right">{{ \App\Models\level::count() }}</span>
            </a>
            <a href="{{ route('departments.index') }}" class="nav-item nav-link"><i class="fa fa-keyboard me-2"></i>
                Department
                <span style="color:#f90808 "class="badge badge-info right">{{ \App\Models\department::count() }}</span>
            </a>
            <a href="{{ route('rooms.index') }}" class="nav-item nav-link"><i class="fa fa-table me-2"></i>Rooms
                <span style="color:#f90808 "class="badge badge-info right">{{ \App\Models\room::count() }}</span>
            </a>
            <a href="{{ route('items.index') }}" class="nav-item nav-link"><i class="fa fa-chart-bar me-2"></i>
                Items
                <span style="color:#f90808 "class="badge badge-info right">{{ \App\Models\item::count() }}</span>
            </a>
        </div>
    </nav>
</div>
<!-- Sidebar End -->
