@extends('layouts.master')


@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content" class="content" style="margin-left: inherit;width: 100%;  margin-top: 50px;">

            <div class="card-body">

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif


                @if (session()->has('edit'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('edit') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif


                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Edit Level</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="{{ route('levels.update', [$level->id]) }}" method="POST">
                        @method('put')
                        @csrf
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Level Name</label>
                                <input type="text" name="name" value="{{ $level->name }}" class="form-control"
                                    required>
                            </div>
                                                            <div class="form-group">
                                    <label for="exampleInputEmail1">Building Name</label>
                                    <select name="build_id" class="form-control" required>
                                        {{-- <option selected>Choose Building</option> --}}
                                        @forelse ($builds as $build)
                                            <option value="{{ $build->id }}" {{$level->build_id ==$build->id?'selected' : ''   }}>{{ $build->name }}</option>
                                        @empty
                                            <option value="" class="text-warning">No Building Found!</option>
                                        @endforelse

                                    </select>
                                </div>
                        </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>


    </div>
    <!-- /.card -->

    wrapper -->

@endsection
