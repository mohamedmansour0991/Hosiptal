@extends('layouts.master')

@section('title')
    Corner Edge| Group
@endsection

@section('content')
    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Levels List</h6>
                    <button type="button" class="btn btn-success m-2"><a style="color: white"
                            href="{{ route('levels.create') }}">Add Level</a></button>
                </div>
                <div class="btn-group" role="group" style=" margin-bottom: 13px;" aria-label="Basic example">
                    <button type="button" class="btn btn-primary"><a style="color: white"
                            href="{{ route('export.excel.level') }}">Export Excel
                        </a></button>
                    <button type="button" class="btn btn-success"><a style="color: white"
                            href="{{ route('import.Level.File.excel') }}">Import Excel </a></button>
                    <button type="button" class="btn btn-danger">Pdf</button>
                    <button type="button" class="btn btn-primary">print</button>
                </div>

                @if (session()->has('delete'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('delete') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif
            @endif
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            {{-- <th scope="col"><input class="form-check-input" type="checkbox"></th> --}}
                            <th scope="col">#</th>
                            @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                <th scope="col">Level Code</th>
                            @endif
                            <th scope="col">Level Name</th>
                            <th scope="col">Building Name</th>
                            <th scope="col">Created_at</th>
                            <th scope="col">updated_at</th>
                            @if (Auth::user()->admin != 0)
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                              @endif
                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($levels as $level)
                            <tr>
                                {{-- <td><input class="form-check-input" type="checkbox"></td> --}}
                                <td>{{ $loop->iteration }}</td>
                                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                    <td>{{ $level->id }}</td>
                                @endif
                                <td>{{ $level->name }}</td>
                                <td>{{ $level->build->name }}</td>
                                <td>{{ $level->created_at }}</td>
                                <td>{{ $level->updated_at }}</td>
                                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                    <td>
                                        <a href="{{ route('levels.edit', $level->id) }}"
                                            class="btn btn-primary rounded-pill m-2" role="button" type="button"
                                            aria-disabled="true">Edit</a>
                                    </td>
                                    <td>

                                        <button type="button"class="btn btn-danger rounded-pill m-2" data-toggle="modal"
                                            data-target="#delete_post{{ $level->id }}">Delete</button>
                                    </td>
                                @endif

                            </tr>

                            @include('levels.destroy')
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Recent Sales End -->


    {{-- <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Levels</h1>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Levels List</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>

                </div>
                <div class="card-body">

                    @if (session()->has('delete'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ \session()->get('delete') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif

                    <a href="{{ route('levels.create') }}" class="btn btn-success" role="button" aria-disabled="true">Add
                        Level</a><br><br>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Level Name </th>
                                <th>Building Name </th>
                                <th>Created_at</th>
                                <th>updated_at</th>
                                <th>Processes</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($levels as $level)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $level->name }}</td>
                                            @foreach ($build as $builds)
                                    <td>{{ $builds->name }}</td>
                            @endforeach

                                    <td>{{ $level->created_at}}</td>
                                    <td>{{ $level->updated_at}}</td>
                                    <td>
                                        <a href="{{ route('levels.edit', $level->id) }}" class="btn btn-primary btn-sm"
                                            role="button" aria-disabled="true">Edit</a>

                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#delete_post{{ $level->id }}">Delete</button>

                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#d_post{{ $level->id }}">Archives</button>
                                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal"
                                            data-target="#delete_post{{ $level->id }}">Show</button>
                                    </td>
                                </tr>
                                @include('levels.destroy')
                            @endforeach
                    </table>
                </div>
            </div>
            <!-- /.card -->

        </section>
        <!-- /.content -->
    </div> --}}
    <!-- /.content-wrapper -->
@endsection
