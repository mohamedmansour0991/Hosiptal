@extends('layouts.master')


@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 100%;margin-top: 50px;">

            <!-- Default box -->


            <div class="card-body">

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif


                @if (session()->has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('success') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Add New Room</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="{{ route('rooms.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Room Name</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Room Code</label>
                                <input type="text" name="code" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Buiding Image</label>
                                <input type="file" name="image" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="build_room">Building Name</label>
                                <select id="build_room" name="build_id" class="form-control" required>
                                    <option selected <option selected>Choose Building</option>
                                    @forelse ($builds as $build)
                                        <option value="{{ $build->id }}">{{ $build->name }}</option>
                                    @empty
                                        <option value="" class="text-warning">No Building Found!</option>
                                    @endforelse

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="level">Level Name</label>
                                <select id="level" name="level_id" class="form-control" required>
                                    <option selected>Choose Level</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="level">Department Name</label>
                                <select id="dept_room" name="dept_id" class="form-control" required>
                                    <option selected>Choose Department</option>
                                </select>
                            </div>


                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
    </div>
    <!-- /.card -->

    </section>
    <!-- /.content -->

    <!-- /.content-wrapper -->

@endsection
