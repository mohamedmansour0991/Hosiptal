@extends('layouts.master')


@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 100%;margin-top: 50px;">

            <!-- Default box -->


            <div class="card-body">

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif


                @if (session()->has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        {{ \session()->get('success') }}
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                @endif

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Eidt Room</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="{{ route('rooms.update', [$room->id]) }}" method="POST" enctype="multipart/form-data">
                        @method('put')
                        @csrf
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Room Name</label>
                                <input type="text" name="name" value="{{ $room->name }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Room Code</label>
                                <input type="text" name="code" value="{{ $room->code }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Buiding Image</label>
                                <input type="file" name="image" value="{{ $room->image }}" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="build_room">Building Name</label>
                                <select id="build_room" name="build_id" class="form-control" required>
                                    @forelse ($builds as $build)
                                        <option value="{{ $build->id }}"
                                            {{ $room->build_id == $build->id ? 'selected' : '' }}>{{ $build->name }}
                                        </option>
                                    @empty
                                        <option value="" class="text-warning">No Building Found!</option>
                                    @endforelse

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="level">Level Name</label>
                                <select id="level" name="level_id" class="form-control" required>
                                    @forelse ($levels as $level)
                                        <option value="{{ $level->id }}"
                                            {{ $room->level_id == $level->id ? 'selected' : '' }}>{{ $level->name }}
                                        </option>
                                    @empty
                                        <option value="" class="text-warning">No Level Found!</option>
                                    @endforelse
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="level">Department Name</label>
                                <select id="level" name="dept_id" class="form-control" required>
                                    @forelse ($depts as $dept)
                                        <option value="{{ $dept->id }}"
                                            {{ $room->dept_id == $dept->id ? 'selected' : '' }}>{{ $dept->name }}
                                        </option>
                                    @empty
                                        <option value="" class="text-warning">No Department Found!</option>
                                    @endforelse
                                </select>
                            </div>
                            <img src="{{ URL('images') . '/' . $room->image }} " style=" margin: 20px;"
                                class="img-fluid rounded-start" alt="Building Image Not Found">


                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
    </div>
    <!-- /.card -->

    </section>
    <!-- /.content-wrapper -->

@endsection
