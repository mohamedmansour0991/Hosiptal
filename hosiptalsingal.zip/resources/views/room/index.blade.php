@extends('layouts.master')

@section('title')
    Corner Edge| Group
@endsection

@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->

        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Rooms List</h6>

                        <button type="button" class="btn btn-success m-2"><a style="color: white"
                                href="{{ route('rooms.create') }}">Add Room</a></button>
                    </div>

                    <div class="btn-group" role="group" style=" margin-bottom: 13px;" aria-label="Basic example">
                        <button type="button" class="btn btn-primary"><a style="color: white"
                                href="{{ route('export.excel.room') }}">Export Excel
                            </a></button>
                        <button type="button" class="btn btn-success"><a style="color: white"
                                href="{{ route('import.room.File.excel') }}">Import Excel </a></button>
                        <button type="button" class="btn btn-danger"><a style="color: white"
                                href="{{ route('pdf.room.covert') }}">Pdf </a></button>

                    </div>
                    @if (session()->has('delete'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i>
                            {{ \session()->get('delete') }}
                            <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                            </button>
                        </div>
                    @endif
                @endif
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                <th scope="col">#</th>
                                @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                    <th scope="col">Room id </th>
                                @endif
                                <th scope="col">Room Name </th>
                                <th scope="col">Room Code </th>
                                <th scope="col">Department Name </th>
                                <th scope="col">Level Name </th>
                                <th scope="col">Building Name </th>
                                <th scope="col">Created_at</th>
                                <th scope="col">updated_at</th>
                                <th scope="col">Room_Image</th>
                                @if (Auth::user()->admin != 0)
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                    <th scope="col">Details</th>
                                @endif

                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($rooms as $room)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                        <td>{{ $room->id }}</td>
                                    @endif
                                    <td>{{ $room->name }}</td>
                                    <td>{{ $room->code }}</td>
                                    <td>{{ $room->dept->name }}</td>
                                    <td>{{ $room->level->name }}</td>
                                    <td>{{ $room->build->name }}</td>
                                    <td>{{ $room->created_at }}</td>
                                    <td>{{ $room->updated_at }}</td>
                                    <td><img src="{{ URL('images') . '/' . $room->image }}"
                                            style=" height:100px; width: 150PX; " class="img-fluid rounded-start"
                                            alt="Room Image Not Found"></td>
                                    @if (Auth::user()->admin == 1 || Auth::user()->admin == 2)
                                        <td>
                                            <a href="{{ route('rooms.edit', $room->id) }}"
                                                class="btn btn-primary rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true">Edit</a>
                                        </td>
                                        <td>
                                            <button type="button"class="btn btn-danger rounded-pill m-2"
                                                data-toggle="modal"
                                                data-target="#delete_post{{ $room->id }}">Delete</button>
                                        </td>
                                        <td>
                                            <a href="{{ route('rooms.show', $room->id) }}" type="button"
                                                class="btn btn-success rounded-pill m-2" role="button"
                                                aria-disabled="true">Details</a>
                                        </td>
                                    @endif
                                </tr>
                                @include('room.destroy')
                            @endforeach
                    </table>
                </div>
            </div>
            <!-- /.card -->
        </div>

        <!-- /.content -->

        <!-- /.content-wrapper -->
    @endsection
