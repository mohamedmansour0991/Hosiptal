<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\pdfControoler;
use Illuminate\Support\Facades\Artisan;
use App\Http\Controllers\ItemControoler;
use App\Http\Controllers\RoomControoler;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ExcelControoler;
use App\Http\Controllers\LevelControoler;
use App\Http\Controllers\BuildingControoler;
use App\Http\Controllers\DashboardControoler;
use App\Http\Controllers\SupDominsControoler;
use App\Http\Controllers\DepartmentControoler;
use App\Http\Controllers\NewProjectControoler;
use App\Http\Controllers\SelectajexControoler;
use App\Models\Tenant;
use FontLib\Table\Type\name;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['status'])->group(
    function () {
        Route::get('/', function () {
            return view('welcome');
        });
    }
);
Route::post('admin', [NewProjectControoler::class,'index']);
// Route::post('subdomain',[SupDominsControoler::class,'store']);
Route::get('/opt', function () {
    return Artisan::call('optimize');
});

// Route::middleware(['auth', 'status'])->group(function () {
//     #--------------------------------dashboard------------------------------------------------
//     Route::resource('dashboard', DashboardControoler::class);
//     #--------------------------------user------------------------------------------------
//     Route::get('users/accept/{id}', [UserController::class, 'accept']);
//     Route::get('users/ban/{id}', [UserController::class, 'ban']);
//     Route::get('users/unban/{id}', [UserController::class, 'unban']);

//     Route::get('users/admin/{id}', [UserController::class, 'admin']);
//     Route::get('users/notadmin/{id}', [UserController::class, 'notadmin']);
//     #--------------------------------Building------------------------------------------------
//     Route::resource('buildings', BuildingControoler::class);
//     #--------------------------------level------------------------------------------------
//     Route::resource('levels', LevelControoler::class);
//     Route::post('/fetch-level/{id}', [SelectajexControoler::class, 'fetchLevel']);

//     #--------------------------------Department------------------------------------------------
//     Route::resource('departments', DepartmentControoler::class);
//     Route::post('/fetch-dept-room/{id}', [SelectajexControoler::class, 'fetchdept']);
//     #--------------------------------Room------------------------------------------------
//     Route::resource('rooms', RoomControoler::class);
//     Route::post('/fetch-level/{id}', [SelectajexControoler::class, 'fetchRoom']);
//     Route::post('/save}', [SelectajexControoler::class, 'save']);
//     #--------------------------------Item------------------------------------------------
//     Route::resource('items', ItemControoler::class);
//     Route::post('/fetch-item/{id}', [SelectajexControoler::class, 'fetchItem']);
//     Route::post('/fetch-item-room/{id}', [SelectajexControoler::class, 'fetchItemRoom']);
//     Route::post('/fetch-item-room-dept/{id}', [SelectajexControoler::class, 'fetchItemRoomDepartment']);
// });



// Route::middleware(['auth', 'admin'])->group(
//     function () {
//         #--------------------------------Excel Building------------------------------------------------
//         Route::get('/export-excel', [ExcelControoler::class, 'export'])->name('export.excel');
//         Route::get('/show', [ExcelControoler::class, 'show'])->name('show.excel');
//         Route::post('/import-excel', [ExcelControoler::class, 'import'])->name('import.excel');
//         #--------------------------------Excel Level------------------------------------------------
//         Route::get('/export-excel-level', [ExcelControoler::class, 'exportLevel'])->name('export.excel.level');
//         Route::get('/import-level-file', [ExcelControoler::class, 'importLevelFile'])->name('import.Level.File.excel');
//         Route::post('/import-excel-level', [ExcelControoler::class, 'importLevel'])->name('import.level');
//         #--------------------------------Excel Department------------------------------------------------
//         Route::get('/export-excel-department', [ExcelControoler::class, 'exportDepartment'])->name('export.excel.department');
//         Route::get('/import-department-file', [ExcelControoler::class, 'importDepartmentFile'])->name('import.department.File.excel');
//         Route::post('/import-excel-department', [ExcelControoler::class, 'importDepartment'])->name('import.department');
//         #--------------------------------Excel Room------------------------------------------------
//         Route::get('/export-excel-room', [ExcelControoler::class, 'exportRoom'])->name('export.excel.room');
//         Route::get('/import-room-file', [ExcelControoler::class, 'importRoomFile'])->name('import.room.File.excel');
//         Route::post('/import-excel-Room', [ExcelControoler::class, 'importRoom'])->name('import.room');
//         #--------------------------------Excel Item------------------------------------------------
//         Route::get('/export-excel-item', [ExcelControoler::class, 'exportItem'])->name('export.excel.item');
//         Route::get('/import-item-file', [ExcelControoler::class, 'importItemFile'])->name('import.item.File.excel');
//         Route::post('/import-excel-item', [ExcelControoler::class, 'importItem'])->name('import.item');


//         #--------------------------------Pdf Building------------------------------------------------
//         Route::get('/pdf-building-view', [pdfControoler::class, 'pdfBuilding'])->name('pdf.building');
//         Route::get('/pdf-covert', [pdfControoler::class, 'pdfBuildingCovert'])->name('pdf.building.covert');

//         #--------------------------------Pdf Item------------------------------------------------
//         Route::get('/pdf-item-view', [pdfControoler::class, 'pdfItem'])->name('pdf.item');
//         Route::get('/pdf-covert-item', [pdfControoler::class, 'pdfItemCovert'])->name('pdf.item.covert');
//     }
// );
// require __DIR__ . '/auth.php';
