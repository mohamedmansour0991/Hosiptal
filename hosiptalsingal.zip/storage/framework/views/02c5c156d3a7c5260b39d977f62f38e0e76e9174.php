<!-- Sidebar Menu -->
<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
        data-accordion="false">
        <li class="nav-item">
            <a href="<?php echo e(route('posts.index')); ?>" class="nav-link">
                <i class="nav-icon far fa-calendar-alt"></i>
                <p>
                    Buildings
                    <span class="badge badge-info right"><?php echo e(\App\Models\building::count()); ?></span>
                </p>
            </a>
                        <a href="<?php echo e(route('levels.index')); ?>" class="nav-link">
                <i class="nav-icon far fa-calendar-alt"></i>
                <p>
                    Levels
                    <span class="badge badge-info right"><?php echo e(\App\Models\level::count()); ?></span>
                </p>
            </a>
                        <a href="<?php echo e(route('departments.index')); ?>" class="nav-link">
                <i class="nav-icon far fa-calendar-alt"></i>
                <p>
                    Department
                    <span class="badge badge-info right"><?php echo e(\App\Models\department::count()); ?></span>
                </p>
            </a>
                        <a href="<?php echo e(route('rooms.index')); ?>" class="nav-link">
                <i class="nav-icon far fa-calendar-alt"></i>
                <p>
                    Rooms
                    <span class="badge badge-info right"><?php echo e(\App\Models\room::count()); ?></span>
                </p>
            </a>
                        <a href="<?php echo e(route('items.index')); ?>" class="nav-link">
                <i class="nav-icon far fa-calendar-alt"></i>
                <p>
                    Items
                    <span class="badge badge-info right"><?php echo e(\App\Models\item::count()); ?></span>
                </p>
            </a>
        </li>
    </ul>
</nav>
<!-- /.sidebar-menu -->
</div>
<!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\hosiptal\resources\views/layouts/main-sidebar.blade.php ENDPATH**/ ?>