<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 100%;margin-top: 50px;">

            <!-- Default box -->


            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                <?php endif; ?>


                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        <?php echo e(\session()->get('success')); ?>

                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                <?php endif; ?>

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Add New Item</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?php echo e(route('items.update', [$item->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Name</label>
                                <input type="text" name="name" value="<?php echo e($item->name); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Group Category</label>
                                <input type="text" name="group_category" value="<?php echo e($item->group_category); ?>"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Group</label>
                                <input type="text" name="group" value="<?php echo e($item->group); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Quantity</label>
                                <input type="text" name="quantity" value="<?php echo e($item->quantity); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Transfer</label>
                                <input type="text" name="transfer" value="<?php echo e($item->transfer); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Unit Cost</label>
                                <input type="text" name="unit_cost" value="<?php echo e($item->unit_cost); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Data</label>
                                <input type="text" name="data" value="<?php echo e($item->data); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">General Specs</label>
                                <input type="text" name="general_specs" value="<?php echo e($item->general_specs); ?>"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Bim Id </label>
                                <input type="text" name="Bim_id" value="<?php echo e($item->Bim_id); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mounting</label>
                                <input type="text" name="mounting" value="<?php echo e($item->mounting); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Weight</label>
                                <input type="text" name="weight" value="<?php echo e($item->weight); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Dimension</label>
                                <input type="text" name="dimension" value="<?php echo e($item->dimension); ?>" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Indicatir</label>
                                <input type="text" name="indicatir" value="<?php echo e($item->indicatir); ?>"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Contact Name</label>
                                <input type="text" name="contact_name" value="<?php echo e($item->contact_name); ?>"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Contact Number</label>
                                <input type="text" name="contact_number" value="<?php echo e($item->contact_number); ?>"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Comments</label>
                                <input type="text" name="comments" value="<?php echo e($item->comments); ?>"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Image</label>
                                <input type="file" name="image" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Detailed Specs Document</label>
                                <input type="file" name="detailed_spec_document" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Revit Model</label>
                                <input type="file" name="revit_model" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Code Model</label>
                                <input type="file" name="code_model" class="form-control" required>
                            </div>


                            <div class="form-group">
                                <label for="build_item">Building Name</label>
                                <select id="build_item" name="build_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($build->id); ?>"
                                            <?php echo e($item->build_id == $build->id ? 'selected' : ''); ?>><?php echo e($build->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Building Found!</option>
                                    <?php endif; ?>

                                </select>
                            </div>

                            <div class="form-group">
                                <label for="level_item">Level Name</label>
                                <select id="level_item" name="level_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($level->id); ?>"
                                            <?php echo e($item->level_id == $level->id ? 'selected' : ''); ?>><?php echo e($level->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Levels Found!</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="dept_item">Deprtment Name</label>
                                <select id="dept_item" name="dept_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option
                                            value="<?php echo e($department->id); ?>" <?php echo e($item->dept_id == $department->id ? 'selected' : ''); ?>>
                                            <?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Department Found!</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="room_item">Room Name</label>
                                <select id="room_item" name="room_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($room->id); ?>"
                                            <?php echo e($item->room_id == $room->id ? 'selected' : ''); ?>><?php echo e($room->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Rooms Found!</option>
                                    <?php endif; ?>
                                </select>
                            </div>


                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Electrical</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="electrical"
                                            id="gridRadios1" value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="electrical"
                                            id="gridRadios2" value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">O2</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="o2" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="o2" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>


                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Air</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="air" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="air" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Tool Air</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="tool_air" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="tool_air" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Vaccum</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="vaccum" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="vaccum" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Agss</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="agss" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="agss" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Water</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="water" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="water" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Drain</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="drain" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="drain" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <fieldset class="row mb-3" style="align-items: center">
                                <legend class="col-form-label col-sm-2 pt-0">Steam</legend>
                                <div class=" col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="steam" id="gridRadios1"
                                            value="Yes" checked>
                                        <label class="form-check-label" for="gridRadios1">
                                            Yes
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="steam" id="gridRadios2"
                                            value="No">
                                        <label class="form-check-label" for="gridRadios2">
                                            No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Comment_After_Edit</label>
                                <input type="text" name="comment_after_edit" value="<?php echo e($item->comment_after_edit); ?>"
                                    class="form-control" required>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
    </div>
    <!-- /.card -->

    </section>
    <!-- /.content -->


<!-- /.content-wrapper --><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptal\resources\views/item/edit.blade.php ENDPATH**/ ?>