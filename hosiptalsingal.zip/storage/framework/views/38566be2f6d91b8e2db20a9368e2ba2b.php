<!-- jQuery -->
<script src="<?php echo e(url('js/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('asset/lib/chart/chart.min.js')); ?>"></script>
<script src="<?php echo e(url('asset/lib/easing/easing.min.js')); ?>"></script>
<script src="<?php echo e(url('asset/lib/waypoints/waypoints.min.js')); ?> "></script>
<script src="<?php echo e(url('asset/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(url('asset/lib/tempusdominus/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('asset/lib/tempusdominus/js/moment-timezone.min.js')); ?>"></script>
<script src="<?php echo e(url('asset/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>

<script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
    $('table').DataTable();
</script>

<!-- Template Javascript -->
<script src="<?php echo e(url('asset/js/main.js')); ?>"></script>
<!-- New -->


<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {
        $('#build_id').change(function() {
            var build_id = $(this).val();
            if (build_id == "") {
                var build_id = 0;
            }
            $.ajax({
                url: '<?php echo e(url('/fetch-level/')); ?>/' + build_id,
                type: "POST",
                dataType: "json",
                data: {
                    somefield: "Some field value",
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#level_dept').find('option:not(:first)').remove();
                    if (response['states'].length > 0) {
                        $.each(response['states'], function(key, value) {
                            $("#level_dept").append("<option value='" + value[
                                'id'] +
                                "'>" + value['name'] + "</option>")
                        });
                    }
                }
                // alert(build_id);
            });
        })
    });
</script>

<script>
    $("#frm").submit(function(event) {
        event.preventDefault();
        $.ajax({
            url: '<?php echo e(url('/departments/store')); ?>',
            type: 'post',
            data: {
                $("#frm").serializeArray(),
                _token: '<?php echo e(csrf_token()); ?>

            },
            dataType: 'json',
            success: function(response) {
                if (response['status'] == 1) {
                    window.location.href = "<?php echo e(url('list')); ?>";
                } else {
                    if (response['errors']['name']) {
                        $("#name").addClass('is-invalid');
                        $("#name-error").html(response['errors']['name']);
                    } else {
                        $("#name").removeClass('is-invalid');
                        $("#name-error").html("");
                    }
                }
            }
        });
    });
</script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {
        $('#build_room').change(function() {
            var build_id = $(this).val();
            if (build_id == "") {
                var build_id = 0;
            }
            $.ajax({
                url: '<?php echo e(url('/fetch-level/')); ?>/' + build_id,
                type: "POST",
                dataType: "json",
                data: {
                    somefield: "Some field value",
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#level').find('option:not(:first)').remove();
                    if (response['states'].length > 0) {
                        $.each(response['states'], function(key, value) {
                            $("#level").append("<option value='" + value['id'] +
                                "'>" + value['name'] + "</option>")
                        });
                    }
                }
                // alert(build_id);
            });
        })
        $("#level").change(function() {
            var level_id = $(this).val();

            console.log(level_id);

            if (level_id == "") {
                var level_id = 0;
            }

            $.ajax({
                url: '<?php echo e(url('/fetch-dept-room/')); ?>/' + level_id,
                type: 'post',
                dataType: 'json',
                data: {
                    somefield: "Some field value",
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#dept_room').find('option:not(:first)').remove();


                    if (response['depts'].length > 0) {
                        $.each(response['depts'], function(key, value) {
                            $("#dept_room").append("<option value='" + value['id'] +
                                "'>" + value['name'] + "</option>")
                        });
                    }
                }
            });
        });
    });
</script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {
        $('#build_item').change(function() {
            var build_id = $(this).val();
            if (build_id == "") {
                var build_id = 0;
            }
            $.ajax({
                url: '<?php echo e(url('/fetch-item/')); ?>/' + build_id,
                type: "POST",
                dataType: "json",
                data: {
                    somefield: "Some field value",
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#level_item').find('option:not(:first)').remove();
                    $('#room_item').find('option:not(:first)').remove();
                    $('#dept_item').find('option:not(:first)').remove();
                    if (response['states'].length > 0) {
                        $.each(response['states'], function(key, value) {
                            $("#level_item").append("<option value='" + value[
                                    'id'] +
                                "'>" + value['name'] + "</option>")
                        });
                    }
                }
                // alert(build_id);
            });
        })

        $("#level_item").change(function() {
            var level_id = $(this).val();

            console.log(level_id);

            if (level_id == "") {
                var level_id = 0;
            }

            $.ajax({
                url: '<?php echo e(url('/fetch-dept-room/')); ?>/' + level_id,
                type: 'post',
                dataType: 'json',
                data: {
                    somefield: "Some field value",
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#room_item').find('option:not(:first)').remove();
                    $('#dept_item').find('option:not(:first)').remove();


                    if (response['depts'].length > 0) {
                        $.each(response['depts'], function(key, value) {
                            $("#dept_item").append("<option value='" + value['id'] +
                                "'>" + value['name'] + "</option>")
                        });
                    }
                }
            });
        });

        $("#dept_item").change(function() {
            var dept_id = $(this).val();

            console.log(dept_id);

            if (dept_id == "") {
                var dept_id = 0;
            }

            $.ajax({
                url: '<?php echo e(url('/fetch-item-room-dept/')); ?>/' + dept_id,
                type: 'post',
                dataType: 'json',
                data: {
                    somefield: "Some field value",
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $('#room_item').find('option:not(:first)').remove();


                    if (response['departments'].length > 0) {
                        $.each(response['departments'], function(key, value) {
                            $("#room_item").append("<option value='" + value['id'] +
                                "'>" + value['name'] + "</option>")
                        });
                    }
                }
            });
        });
    });
</script>

<?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/layouts/footer-scripts.blade.php ENDPATH**/ ?>