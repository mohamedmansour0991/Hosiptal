


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 97%;margin-top: 50px;">





            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Show Room</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->

                <div class="card-body">
                    <div class="card mb-3" style="">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="<?php echo e(URL('images').'/'. $room->image); ?> "
                                    class="img-fluid rounded-start" alt="Building Image Not Found">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body  ">
                                    <h5 class="card-title " style="font-size: 25px"> Room Name : <span style="color: red"><?php echo e($room->name); ?></span></h5>
                                    <h5 class="card-title " style="font-size: 18px">Room Code : <span style="color: red"><?php echo e($room->code); ?></span></h5>
                                    <h5 class="card-title " style="font-size: 18px">Room Level : <span style="color: red"><?php echo e($room->level->name); ?></span></h5>
                                    <h5 class="card-title " style="font-size: 18px">Room Building : <span style="color: red"><?php echo e($room->build->name); ?></span></h5>
                                    
                                    </p>
                                    <p class="card-text"><small class="text-muted">Last updated <span style="color: red"> <?php echo e($room->updated_at); ?></span>
                                            mins ago</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/room/show.blade.php ENDPATH**/ ?>