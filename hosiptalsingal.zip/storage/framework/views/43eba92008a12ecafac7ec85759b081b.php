


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Show Building Name : <span class="text-danger"><?php echo e($post->name); ?></span></h1>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('edit')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(\session()->get('edit')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            
                        </div>
                    <?php endif; ?>


                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Show Building</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        
                        <div class="card-body">
                            <div class="card mb-3" style="">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="<?php echo e(URL::asset('storage').'/'.$post->image); ?> " class="img-fluid rounded-start" alt="Building Image Not Found">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body  "  >
                                            <h5 class="card-title " style="font-size: 30px"><?php echo e($post->name); ?></h5>
                                            <p class="card-text">This is image for Building <?php echo e($post->name); ?>  .
                                            </p>
                                            <p class="card-text"><small class="text-muted">Last updated <?php echo e($post->updated_at); ?> mins ago</small>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
    </div>
    <!-- /.card -->

    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptal\resources\views/posts/show.blade.php ENDPATH**/ ?>