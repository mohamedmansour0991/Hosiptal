
<title><?php echo $__env->yieldContent('title'); ?></title>

<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome -->
<link href="<?php echo e(URL::asset('css/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
<!-- Theme style -->
<link href="<?php echo e(URL::asset('css/adminlte.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(URL::asset('datatables/css/datatables-bs4/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('datatables/css/datatables-responsive/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('datatables/css/datatables-buttons/buttons.bootstrap4.min.css')); ?>" rel="stylesheet">




<?php /**PATH F:\xampp\htdocs\API-Course-For-Beginners-1-create_route_and_controller_and_return_response_api\resources\views/layouts/head.blade.php ENDPATH**/ ?>