<style>
    body {
        margin: 0;
        padding: 1cm 2cm;
        color: black;
        font-family: 'Montserrat', sans-serif;
        font-size: 10pt;
    }


    a {
        color: inherit;
        text-decoration: none;
    }


    hr {
        margin: 1cm 0;
        height: 0;
        border: 0;
        border-top: 1mm solid #60D0E4;
    }


    header {
        height: 8cm;
        padding: 0 2cm;
        position: running(header);
        background-color: #B8E6F1;
    }


    header .headerSection {
        display: flex;
        justify-content: space-between;
    }

    td {
        border: 1px solid rgb(200, 200, 223);
        text-align: center;
    }

    th {
        border: 1px solid rgb(200, 200, 223);
        text-align: center;
    }

    header .headerSection:first-child {
        padding-top: .5cm;
    }


    header .headerSection:last-child {
        padding-bottom: .5cm;
    }


    header .headerSection div:last-child {
        width: 35%;
    }


    header .logoAndName {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }


    header .logoAndName svg {
        width: 1.5cm;
        height: 1.5cm;
        margin-right: .5cm;
    }


    header .headerSection .estimateDetails {
        padding-top: 1cm;
    }


    header .headerSection .issuedTo {
        display: flex;
        justify-content: space-between;
    }


    header .headerSection .issuedTo h3 {
        margin: 0 .75cm 0 0;
        color: #60D0E4;
    }


    header .headerSection div p {
        margin-top: 2px;
    }


    header h1,
    header h2,
    header h3,
    header p {
        margin: 0;
    }


    header h2,
    header h3 {
        text-transform: uppercase;
    }


    header hr {
        margin: 1cm 0 .5cm 0;
    }


    main table {
        width: 100%;
        border-collapse: collapse;
    }


    main table thead th {
        height: 1cm;
        text-align: center;
        color: #60D0E4;
    }




    main table tbody td {
        padding: 4mm 2px;
    }








    main table.summary {
        margin-top: .5cm;
    }


    main table.summary tr.total {
        font-weight: bold;
        background-color: #60D0E4;
    }


    main table.summary th {
        padding: 4mm 0 4mm 1cm;
        border-bottom: 0;
    }

    main table.summary td {
        padding: 4mm 2cm 4mm 0;
        border-bottom: 0;
    }




    main table.summary1 {
        margin-top: .5cm;
        margin-bottom: 0.5cm;
            width: 100%;
    }


    main table.summary1 tr {
        font-weight: bold;
        background-color: #4fcd6d;
    }


    main table.summary1 th {
    padding: 4mm 0 4mm 2mm;
    border-bottom: 0;
}
    

    main table.summary1 td {
        padding: 4mm 0cm 4mm 0;
        border-bottom: 0;
    }
</style>

<div class="headerSection">
    <!-- As a logo we take an SVG element and add the name in an standard H1 element behind it. -->
    <div class="logoAndName">
        <img src="logo.jpg" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
            style="border-radius: 50%;opacity: .8;width: 50px; ">
        <h1>Corner Edge Group</h1>
    </div>
    <!-- Details about the estimation are on the right top side of each page. -->
    <div>
        <h2>HOSPITAL EQUIPMENT PLANNING SYSTEM (HEPS)
            GEHU Endoscopy & Procedure Unit Expansion: FF&E Master List with Make and Model and Price</h2>
        <p>
            <b>Date Issued :</b> <?php echo e(date('Y-m-d & H:i:s')); ?>

        </p>
        <p>
            <?php
                $tenants = App\Models\Tenant::get('id');
            ?>
            <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <b>Project Name :</b> <?php echo e($ten->id); ?>

        </p>
    </div>
</div>

<hr />
<div class="headerSection">

    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <main>



            <table class="summary1">

                <tr class="">
                    <th>
                        Bilding Name
                    </th>
                    <td>
                        <?php echo e($room->build->name); ?>

                    </td>
                    <th>
                        Room Name
                    </th>
                    <td>

                        <?php echo e($room->name); ?>

                    </td>
                    <th>
                        Total
                    </th>
                    <td>
                        <?php echo e(\App\Models\item::where('room_id', $room->id)->sum('total_cost')); ?> £E
                    </td>
                </tr>

            </table>
            <table>
                <thead>
                    <tr>
                        <th  style="height: 0%;width:0px;border:none"></th>
                        <th >Item_Name </th>
                        <th >Bim Id</th>
                        <th >ndicative Make and Model</th>
                        <th >Unit Cost</th>
                        <th >Requirement Quantity </th>
                        <th >Total_Cost </th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($room->id == $item->room_id): ?>
                        <tbody>

                            <tr>
                                <td style="height: 0%;width:0px;border:none"></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->Bim_id); ?></td>
                                <td><?php echo e($item->indicatir); ?></td>
                                <td><?php echo e($item->unit_cost); ?></td>
                                <td><?php echo e($item->requirement_qty); ?></td>
                                <td><?php echo e($item->total_cost); ?> £E</td>
                            <tr>
                        </tbody>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <table class="summary">

        <tr class="total">
            <th>
                Building Number
            </th>
            <td>
                <?php echo e(\App\Models\building::count()); ?>

            </td>
            <th>
                Total
            </th>
            <td>
                <?php echo e(\App\Models\item::sum('total_cost')); ?> £E
            </td>
        </tr>

    </table>
    </main>
<?php /**PATH C:\laragon\www\hosiptal\resources\views/pdf/room.blade.php ENDPATH**/ ?>