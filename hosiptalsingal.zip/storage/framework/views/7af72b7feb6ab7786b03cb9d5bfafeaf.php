<?php $__env->startSection('title'); ?>
    Corner Edge| Group
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->

        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Rooms List</h6>

                        <button type="button" class="btn btn-success m-2"><a style="color: white"
                                href="<?php echo e(route('rooms.create')); ?>">Add Room</a></button>
                    </div>

                    <div class="btn-group" role="group" style=" margin-bottom: 13px;" aria-label="Basic example">
                        <button type="button" class="btn btn-primary"><a style="color: white"
                                href="<?php echo e(route('export.excel.room')); ?>">Export Excel
                            </a></button>
                        <button type="button" class="btn btn-success"><a style="color: white"
                                href="<?php echo e(route('import.room.File.excel')); ?>">Import Excel </a></button>
                        <button type="button" class="btn btn-danger"><a style="color: white"
                                href="<?php echo e(route('pdf.room.covert')); ?>">Pdf </a></button>

                    </div>
                    <?php if(session()->has('delete')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i>
                            <?php echo e(\session()->get('delete')); ?>

                            <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                            </button>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                <th scope="col">#</th>
                                <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                    <th scope="col">Room id </th>
                                <?php endif; ?>
                                <th scope="col">Room Name </th>
                                <th scope="col">Room Code </th>
                                <th scope="col">Department Name </th>
                                <th scope="col">Level Name </th>
                                <th scope="col">Building Name </th>
                                <th scope="col">Created_at</th>
                                <th scope="col">updated_at</th>
                                <th scope="col">Room_Image</th>
                                <?php if(Auth::user()->admin != 0): ?>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                    <th scope="col">Details</th>
                                <?php endif; ?>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                        <td><?php echo e($room->id); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($room->name); ?></td>
                                    <td><?php echo e($room->code); ?></td>
                                    <td><?php echo e($room->dept->name); ?></td>
                                    <td><?php echo e($room->level->name); ?></td>
                                    <td><?php echo e($room->build->name); ?></td>
                                    <td><?php echo e($room->created_at); ?></td>
                                    <td><?php echo e($room->updated_at); ?></td>
                                    <td><img src="<?php echo e(URL('storage') . '/' . $room->image); ?>"
                                            style=" height:100px; width: 150PX; " class="img-fluid rounded-start"
                                            alt="Room Image Not Found"></td>
                                    <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                        <td>
                                            <a href="<?php echo e(route('rooms.edit', $room->id)); ?>"
                                                class="btn btn-primary rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true">Edit</a>
                                        </td>
                                        <td>
                                            <button type="button"class="btn btn-danger rounded-pill m-2"
                                                data-toggle="modal"
                                                data-target="#delete_post<?php echo e($room->id); ?>">Delete</button>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('rooms.show', $room->id)); ?>" type="button"
                                                class="btn btn-success rounded-pill m-2" role="button"
                                                aria-disabled="true">Details</a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <?php echo $__env->make('room.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <!-- /.card -->
        </div>

        <!-- /.content -->

        <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptal\resources\views/room/index.blade.php ENDPATH**/ ?>