


<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 97%;margin-top: 50px;">





            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Show Building</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->

                <div class="card-body">
                    <div class="card mb-3" style="">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="<?php echo e(url('images').'/'.$building->image); ?> "
                                    class="img-fluid rounded-start" alt="Building Image Not Found">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body  ">
                                    <h5 class="card-title " style="font-size: 30px"><?php echo e($building->name); ?></h5>
                                    <p class="card-text">This is image for Building <?php echo e($building->name); ?> .
                                    </p>
                                    <p class="card-text"><small class="text-muted">Last updated <?php echo e($building->updated_at); ?>

                                            mins ago</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/building/show.blade.php ENDPATH**/ ?>