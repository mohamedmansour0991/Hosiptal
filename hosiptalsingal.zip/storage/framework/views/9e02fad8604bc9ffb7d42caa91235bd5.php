<?php
    $tenants = \App\Models\Tenant::all();
?>

<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="<?php echo e(route('dashboard.index')); ?>" class="navbar-brand d-flex d-lg-none me-4">
            <img src="logo.jpg" alt="Logo" class="brand-image img-circle elevation-3"
                style="border-radius: 50%;opacity: .8;width: 50px; ">
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <div class="navbar-nav align-items-center ms-auto">



            <div class="navbar-nav align-items-center ms-auto">
                <?php if(Auth::user()->admin != 0): ?>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-th" me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">New project</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <form action="<?php echo e(route('subdomain.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <p>Project Name ?</p>
                                <div class="form-outline mb-4">
                                    <input id="email" name="subdomain" class="form-control" required
                                         placeholder=" Project Name" autofocus autocomplete="off" >
                                </div>
                                <div class="text-center pt-1 mb-5 pb-1">
                                    <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3"
                                        type="submit">Create</button>

                                </div>

                            </form>

                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-laptop " me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">All projects</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#" class="dropdown-item">
                                    <div class="d-flex align-items-left">
                                        <div class="">
                                            <h6 class="fw-normal mb-0"><?php echo e($tenant->id); ?></h6>
                                        </div>
                                        <?php $__currentLoopData = $tenant->domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a target="blank" href="http://<?php echo e($domain->domain); ?>:8000/">link</a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </a>
                                <hr class="dropdown-divider">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
            </div>
            <?php endif; ?>

            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="avatar.png" alt=""
                        style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo e(Auth::user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a class="dropdown-item" href="#"
                            onclick="event.preventDefault();
                        this.closest('form').submit();">
                            Log out</a>
                    </form>
                </div>
            </div>

        </div>
    </nav>
    <!-- Navbar End -->
<?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/layouts/main-header.blade.php ENDPATH**/ ?>