<style>
    body {
        margin: 0;
        padding: 1cm 2cm;
        color: black;
        font-family: 'Montserrat', sans-serif;
        font-size: 10pt;
    }


    a {
        color: inherit;
        text-decoration: none;
    }


    hr {
        margin: 1cm 0;
        height: 0;
        border: 0;
        border-top: 1mm solid #60D0E4;
    }


    header {
        height: 8cm;
        padding: 0 2cm;
        position: running(header);
        background-color: #B8E6F1;
    }


    header .headerSection {
        display: flex;
        justify-content: space-between;
    }

    td {
        border: 1px solid rgb(200, 200, 223);
        text-align: center;
    }

    th {
        border: 1px solid rgb(200, 200, 223);
        text-align: center;
    }

    header .headerSection:first-child {
        padding-top: .5cm;
    }


    header .headerSection:last-child {
        padding-bottom: .5cm;
    }


    header .headerSection div:last-child {
        width: 35%;
    }


    header .logoAndName {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }


    header .logoAndName svg {
        width: 1.5cm;
        height: 1.5cm;
        margin-right: .5cm;
    }


    header .headerSection .estimateDetails {
        padding-top: 1cm;
    }


    header .headerSection .issuedTo {
        display: flex;
        justify-content: space-between;
    }


    header .headerSection .issuedTo h3 {
        margin: 0 .75cm 0 0;
        color: #60D0E4;
    }


    header .headerSection div p {
        margin-top: 2px;
    }


    header h1,
    header h2,
    header h3,
    header p {
        margin: 0;
    }


    header h2,
    header h3 {
        text-transform: uppercase;
    }


    header hr {
        margin: 1cm 0 .5cm 0;
    }


    main table {
        width: 100%;
        border-collapse: collapse;
    }


    main table thead th {
        height: 1cm;
        text-align: center;
        color: #60D0E4;
    }



    main table thead th:nth-of-type(2),
    main table thead th:nth-of-type(3),
    main table thead th:last-of-type {
        width: 4cm;
    }


    main table tbody td {
        padding: 2mm 0;
    }





    main table th {
        text-align: left;
    }


    main table.summary {
        margin-top: .5cm;
    }


    main table.summary tr.total {
        font-weight: bold;
        background-color: #60D0E4;
    }


    main table.summary th {
        padding: 4mm 0 4mm 1cm;
        border-bottom: 0;
    }

    main table.summary td {
        padding: 4mm 2cm 4mm 0;
        border-bottom: 0;
    }
</style>

<div class="headerSection">
    <!-- As a logo we take an SVG element and add the name in an standard H1 element behind it. -->
    <div class="logoAndName">
        <img src="logo.jpg" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
            style="border-radius: 50%;opacity: .8;width: 50px; ">
        <h1>Corner Edge Group</h1>
    </div>
    <!-- Details about the estimation are on the right top side of each page. -->
    <div>
        <h2>HOSPITAL EQUIPMENT PLANNING SYSTEM (HEPS)
            GEHU Endoscopy & Procedure Unit Expansion: FF&E Master List with Make and Model and Price</h2>
        <p>
            <b>Date Issued :</b> <?php echo e(date('Y-m-d & H:i:s')); ?>

        </p>
        <p>
            <b>Project Name :</b> <?php echo e(Auth::user()->tenant_id); ?>

        </p>
    </div>
</div>

<hr />
<div class="headerSection">







    <main>
        <table>
            <thead>
                <tr>
                    <th>Building Name</th>



                    <th>Levels</th>


                    <th>Departments</th>


                    <th>Rooms</th>


                    <th>items</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($building->name); ?></td>
                        <td><?php echo e(\App\Models\level::where('build_id', $building->id)->count()); ?></td>
                        <td><?php echo e(\App\Models\department::where('build_id', $building->id)->count()); ?></td>
                        <td><?php echo e(\App\Models\room::where('build_id', $building->id)->count()); ?></td>
                        <td><?php echo e(\App\Models\item::where('build_id', $building->id)->count()); ?></td>

                        <td>
                            <?php echo e(\App\Models\item::where('build_id', $building->id)->sum('total_cost')); ?> £E
                        </td>

                    <tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
        <table class="summary">

            <tr class="total">
                <th>
                    Building Number
                </th>
                <td>
                    <?php echo e(\App\Models\building::count()); ?>

                </td>
                <th>
                    Total
                </th>
                <td>
                    <?php echo e(\App\Models\item::sum('total_cost')); ?> £E
                </td>
            </tr>

        </table>
    </main>
<?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/pdf/buildingPdf.blade.php ENDPATH**/ ?>