        

        <!-- Content Header (Page header) -->


        <!-- Main content -->

        <?php $__env->startSection('content'); ?>

            <form style="    margin-top: 150px;width: 90%;margin-bottom: 315px;margin-left: 27px;"
                action="<?php echo e(route('import.department')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                <?php endif; ?>


                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        <?php echo e(\session()->get('success')); ?>

                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Import File</label>
                    <input type="file" name="file" class="form-control" required>
                </div>
                <div class="card-footer">
                    <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                </div>
            </form>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptal\resources\views/extracts/importDepartment.blade.php ENDPATH**/ ?>