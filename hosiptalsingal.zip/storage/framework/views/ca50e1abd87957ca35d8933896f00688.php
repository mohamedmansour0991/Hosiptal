<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content" style="margin-left: inherit;width: 100%;margin-top: 50px;">

            <!-- Default box -->


            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                <?php endif; ?>


                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa fa-exclamation-circle me-2"></i>
                        <?php echo e(\session()->get('success')); ?>

                        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                        </button>
                    </div>
                <?php endif; ?>

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Eidt Room</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?php echo e(route('rooms.update', [$room->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Room Name</label>
                                <input type="text" name="name" value="<?php echo e($room->name); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Room Code</label>
                                <input type="text" name="code" value="<?php echo e($room->code); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Buiding Image</label>
                                <input type="file" name="image" value="<?php echo e($room->image); ?>" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="build_room">Building Name</label>
                                <select id="build_room" name="build_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($build->id); ?>"
                                            <?php echo e($room->build_id == $build->id ? 'selected' : ''); ?>><?php echo e($build->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Building Found!</option>
                                    <?php endif; ?>

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="level">Level Name</label>
                                <select id="level" name="level_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($level->id); ?>"
                                            <?php echo e($room->level_id == $level->id ? 'selected' : ''); ?>><?php echo e($level->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Level Found!</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="level">Department Name</label>
                                <select id="level" name="dept_id" class="form-control" required>
                                    <?php $__empty_1 = true; $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($dept->id); ?>"
                                            <?php echo e($room->dept_id == $dept->id ? 'selected' : ''); ?>><?php echo e($dept->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="" class="text-warning">No Department Found!</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <img src="<?php echo e(URL('images') . '/' . $room->image); ?> " style=" margin: 20px;"
                                class="img-fluid rounded-start" alt="Building Image Not Found">


                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" style="width: 100%;" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
    </div>
    <!-- /.card -->

    </section>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/room/edit.blade.php ENDPATH**/ ?>