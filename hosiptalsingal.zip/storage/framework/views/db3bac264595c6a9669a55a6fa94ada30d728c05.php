<?php $__env->startSection('title'); ?>
    Corner Edge| Group
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Buildings</h1>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Building List</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>

                </div>
                <div class="card-body">

                    <?php if(session()->has('delete')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(\session()->get('delete')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success" role="button" aria-disabled="true">Add
                        Building</a><br><br>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Building Name </th>
                                <th>Image</th>
                                <th>Created_at</th>
                                <th>updated_at</th>
                                <th>Processes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($post->name); ?></td>
                                    <td><?php echo e($post->image); ?></td>
                                    <td><?php echo e($post->created_at); ?></td>
                                    <td><?php echo e($post->updated_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-primary btn-sm"
                                            role="button" aria-disabled="true">Edit</a>
                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#delete_post<?php echo e($post->id); ?>">Delete</button>
                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#d_post<?php echo e($post->id); ?>">Archives</button>
                                      <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-success btn-sm"
                                            role="button" aria-disabled="true">Show</a>
                                    </td>
                                </tr>
                                <?php echo $__env->make('posts.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <!-- /.card -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptal\resources\views/posts/index.blade.php ENDPATH**/ ?>