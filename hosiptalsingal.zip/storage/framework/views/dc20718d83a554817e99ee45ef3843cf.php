









    <!-- Content Start -->
    <div class="content">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="navbar-brand d-flex d-lg-none me-4">
                        <img src="logo.jpg" alt="Logo" class="brand-image img-circle elevation-3"
             style="border-radius: 50%;opacity: .8;width: 50px; ">
            </a>
            <a href="#" class="sidebar-toggler flex-shrink-0">
                <i class="fa fa-bars"></i>
            </a>
            <div class="navbar-nav align-items-center ms-auto">





                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <img class="rounded-circle me-lg-2" src="avatar.png" alt=""
                            style="width: 40px; height: 40px;">
                        <span class="d-none d-lg-inline-flex"><?php echo e(Auth::user()->name); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                        
                        
                            
                    </div>
                </div>
            </div>
        </nav>
        <!-- Navbar End -->
<?php /**PATH C:\laragon\www\hosiptal\resources\views/layouts/main-header.blade.php ENDPATH**/ ?>