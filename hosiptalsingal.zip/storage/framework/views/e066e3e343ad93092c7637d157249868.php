<?php $__env->startSection('title'); ?>
    Corner Edge| Group
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->

        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0"> Items List</h6>

                        <button type="button" class="btn btn-success m-2"><a style="color: white"
                                href="<?php echo e(route('items.create')); ?>">Add Item </a></button>
                    </div>
                    <div class="btn-group" role="group" style=" margin-bottom: 13px;" aria-label="Basic example">
                        <button type="button" class="btn btn-primary"><a style="color: white"
                                href="<?php echo e(route('export.excel.item')); ?>">Export Excel
                            </a></button>
                        <button type="button" class="btn btn-success"><a style="color: white"
                                href="<?php echo e(route('import.item.File.excel')); ?>">Import Excel </a></button>
                        <button type="button" class="btn btn-danger"><a style="color: white"
                                href="<?php echo e(route('pdf.item.covert')); ?>">Pdf </a></button>
                    </div>

                    <?php if(session()->has('delete')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-circle me-2"></i>
                            <?php echo e(\session()->get('delete')); ?>

                            <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">

                            </button>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">

                        <thead>
                            <tr class="text-dark">
                                <th scope="col">#</th>
                                <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                    <th scope="col">Item Code </th>
                                <?php endif; ?>
                                <th scope="col">Item_Name </th>
                                <th scope="col">Item_Group Category</th>
                                <th scope="col">Item_Group </th>
                                <th scope="col">Item Quantity </th>
                                <th scope="col">Item Transfer </th>
                                <th scope="col">Unit Cost</th>
                                <th scope="col">Requirement Quantity </th>
                                <th scope="col">Total_Cost </th>
                                <th scope="col">Bim Id</th>
                                <th scope="col">Data </th>
                                <th scope="col">General_Specs </th>
                                <th scope="col">Electrical </th>
                                <th scope="col">O2</th>
                                <th scope="col">Air </th>
                                <th scope="col">Tool_Air</th>
                                <th scope="col">vaccum</th>
                                <th scope="col">Agss </th>
                                <th scope="col">water </th>
                                <th scope="col">Drain </th>
                                <th scope="col">Steam</th>
                                <th scope="col">Mounting </th>
                                <th scope="col">Weight </th>
                                <th scope="col">Dimension </th>
                                <th scope="col">Indicatir</th>
                                <th scope="col">Contact Name </th>
                                <th scope="col">Contact Number </th>
                                <th scope="col">Room Name</th>
                                <th scope="col">Department Name </th>
                                <th scope="col">Level Name </th>
                                <th scope="col">Building Name </th>
                                <th scope="col">Comment </th>
                                <th scope="col">Created_at</th>
                                <th scope="col">updated_at</th>
                                <th scope="col">_Item_Image_ </th>
                                <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                    <th scope="col">Comment_After_Edit </th>
                                    <th scope="col">detailed Spec Documen </th>
                                    <th scope="col">Revit Model </th>
                                    <th scope="col">Code Model </th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                    <th scope="col">Details</th>
                                <?php endif; ?>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                        <td><?php echo e($item->id); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->group_category); ?></td>
                                    <td><?php echo e($item->group); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->transfer); ?></td>
                                    <td><?php echo e($item->unit_cost); ?></td>
                                    <td><?php echo e($item->requirement_qty); ?></td>
                                    <td><?php echo e($item->total_cost); ?> £E</td>
                                    <td><?php echo e($item->Bim_id); ?></td>
                                    <td><?php echo e($item->data); ?></td>
                                    <td><?php echo e($item->general_specs); ?></td>
                                    <td><?php echo e($item->electrical); ?></td>
                                    <td><?php echo e($item->o2); ?></td>
                                    <td><?php echo e($item->air); ?></td>
                                    <td><?php echo e($item->tool_air); ?></td>
                                    <td><?php echo e($item->vaccum); ?></td>
                                    <td><?php echo e($item->agss); ?></td>
                                    <td><?php echo e($item->water); ?></td>
                                    <td><?php echo e($item->drain); ?></td>
                                    <td><?php echo e($item->steam); ?></td>
                                    <td><?php echo e($item->mounting); ?></td>
                                    <td><?php echo e($item->weight); ?></td>
                                    <td><?php echo e($item->dimension); ?></td>
                                    <td><?php echo e($item->indicatir); ?></td>
                                    <td><?php echo e($item->contact_name); ?></td>
                                    <td><?php echo e($item->contact_number); ?></td>
                                    <td><?php echo e($item->room_id); ?></td>
                                    <td><?php echo e($item->dept_id); ?></td>
                                    <td><?php echo e($item->level_id); ?></td>
                                    <td><?php echo e($item->build_id); ?></td>
                                    <td><?php echo e($item->comments); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td><?php echo e($item->updated_at); ?></td>
                                    <td><img src="images<?php echo e(url(''). '/'. $item->image); ?> "
                                            style=" height:100px; width: 150PX; " class="img-fluid rounded-start"
                                            alt="Item Image Not Found"></td>
                                    <?php if(Auth::user()->admin == 1 || Auth::user()->admin == 2): ?>
                                        <td><?php echo e($item->comment_after_edit); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('download1.file', $item->id)); ?>"
                                                class="btn btn-success rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true"><i class="fa fa-download "></i></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('items.edit', $item->id)); ?>"
                                                class="btn btn-success rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true"><i class="fa fa-download "></i></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('items.edit', $item->id)); ?>"
                                                class="btn btn-success rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true"><i class="fa fa-download "></i></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('items.edit', $item->id)); ?>"
                                                class="btn btn-primary rounded-pill m-2" role="button" type="button"
                                                aria-disabled="true">Edit</a>
                                        </td>
                                        <td>
                                            <button type="button"class="btn btn-danger rounded-pill m-2"
                                                data-toggle="modal"
                                                data-target="#delete_post<?php echo e($item->id); ?>">Delete</button>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('items.show', $item->id)); ?>" type="button"
                                                class="btn btn-success rounded-pill m-2" role="button"
                                                aria-disabled="true">Details</a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <?php echo $__env->make('item.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <!-- /.card -->

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/item/index.blade.php ENDPATH**/ ?>