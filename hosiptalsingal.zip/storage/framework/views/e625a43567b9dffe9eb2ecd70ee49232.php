

<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-light navbar-light">
        <a href=" <?php echo e(route('dashboard.index')); ?>" class="navbar-brand mx-4 mb-3">
            <h3 class="text-primary"> <img src="<?php echo e(url('logo.jpg ')); ?> " alt=" Logo"
                    class="brand-image img-circle elevation-3"
                    style="border-radius: 50%;opacity: .8;width: 50px; margin-right: 5px; ">Corner
                Edge</h3>
        </a>
        <div class="d-flex align-items-center ms-4 mb-4">
            <div class="position-relative">
                <img class="rounded-circle" src="<?php echo e(url('avatar.png')); ?>" alt=""
                    style="width: 40px; height: 40px;">
                <div
                    class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1">
                </div>
            </div>
            <div class="ms-3">
                <h6 class="mb-0"><?php echo e(Auth::user()->name); ?></h6>
                <span>

                        <?php if(Auth::user()->admin == 0): ?>
                            <span style="color: green">User</span>
                        <?php elseif(Auth::user()->admin == 1): ?>
                            
                            <span style="color: rgb(171, 207, 39)">Admin</span>
                        <?php else: ?>
                            
                            <span style="color:gold">Super Admin</span>
                        <?php endif; ?>
                </span>
            </div>
        </div>
        <div class="navbar-nav w-100">
            <a href=" <?php echo e(route('dashboard.index')); ?>" class="nav-item nav-link active"><i
                    class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
            <a href="<?php echo e(route('buildings.index')); ?>" class="nav-item nav-link"><i class="fa fa-home me-2"></i>
                Buildings
                <span style="color:#f90808 " class="badge badge-info right"><?php echo e(\App\Models\building::count()); ?></span>
            </a>
            <a href="<?php echo e(route('levels.index')); ?>" class="nav-item nav-link"><i class="fa fa-th me-2"></i>
                Levels
                <span style="color:#f90808 "class="badge badge-info right"><?php echo e(\App\Models\level::count()); ?></span>
            </a>
            <a href="<?php echo e(route('departments.index')); ?>" class="nav-item nav-link"><i class="fa fa-keyboard me-2"></i>
                Department
                <span style="color:#f90808 "class="badge badge-info right"><?php echo e(\App\Models\department::count()); ?></span>
            </a>
            <a href="<?php echo e(route('rooms.index')); ?>" class="nav-item nav-link"><i class="fa fa-table me-2"></i>Rooms
                <span style="color:#f90808 "class="badge badge-info right"><?php echo e(\App\Models\room::count()); ?></span>
            </a>
            <a href="<?php echo e(route('items.index')); ?>" class="nav-item nav-link"><i class="fa fa-chart-bar me-2"></i>
                Items
                <span style="color:#f90808 "class="badge badge-info right"><?php echo e(\App\Models\item::count()); ?></span>
            </a>
        </div>
    </nav>
</div>
<!-- Sidebar End -->
<?php /**PATH C:\laragon\www\hosiptalsingal\resources\views/layouts/main-sidebar.blade.php ENDPATH**/ ?>