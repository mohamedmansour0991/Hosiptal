
<?php $__env->startSection('title'); ?>
    Corner Edge| Group
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Cost</p>
                        <h6 class="mb-0"><?php echo e(\App\Models\item::sum('total_cost')); ?> £E</h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-bar fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Item Requir</p>
                        <h6 class="mb-0"><?php echo e(\App\Models\item::count('requirement_qty')); ?> </h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-area fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2"> Item Transfer</p>
                        <h6 class="mb-0"><?php echo e(\App\Models\item::count('transfer')); ?> </h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-pie fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Building</p>
                        <h6 class="mb-0"><?php echo e(\App\Models\building::count()); ?> </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Sale & Revenue End -->

    <?php if(Auth::user()->admin != 0): ?>
        <!-- Recent Sales Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Recent Salse</h6>
                    <p style="color: red">User Paid <span style="color: rgb(226, 13, 13)">(
                            <?php echo e(\App\Models\User::where('status', 2)->count()); ?> )</span> </p>
                </div>

                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                
                                <th scope="col">User Name</th>
                                <th scope="col">User Email</th>
                                <th scope="col">User Type</th>
                                <th scope="col">Status</th>
                                <?php if($user->admin == 2 ): ?>
                                    <th scope="col">Action</th>
                                <?php endif; ?>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->admin == 0): ?>
                                            <span style="color: green">User</span>
                                        <?php elseif($user->admin == 1): ?>
                                            <span style="color: rgb(171, 207, 39)">Admin</span>
                                        <?php else: ?>
                                            <span style="color:gold">Super Admin</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($user->status == 2): ?>
                                            <span style="color: rgb(39, 207, 199)">Paid</span>
                                        <?php elseif($user->status == 1): ?>
                                            <span style="color: green">Active</span>
                                        <?php else: ?>
                                            <span style="color: red">Block</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>

                                        <?php if($user->status == 2): ?>
                                            <button class="btn btn-sm btn-success"
                                                onclick="window.location='<?php echo e(url("users/accept/$user->id")); ?>'">Accept</button>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->admin == 2): ?>
                                            <?php if($user->admin == 0): ?>
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="window.location='<?php echo e(url("users/admin/$user->id")); ?>'">Admin</button>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-primary"
                                                    onclick="window.location='<?php echo e(url("users/notadmin/$user->id")); ?>'">UnAdmin</button>
                                            <?php endif; ?>
                                            <?php if($user->status == 1): ?>
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="window.location='<?php echo e(url("users/ban/$user->id")); ?>'">Block</button>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-success"
                                                    onclick="window.location='<?php echo e(url("users/unban/$user->id")); ?>'">UnBlock</button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Recent Sales End -->
    <?php endif; ?>

    <!-- Widgets Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-8 col-xl-8">
                <div class="h-100 bg-light rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <h6 class="mb-0">Project Managers</h6>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="asset/img/user.jpg" alt=""
                            style="width: 40px; height: 40px;">
                        <div class="w-100 ms-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-0">Jhon Doe</h6>
                                <a href="" class="btn btn-success  " role="button" type="button"
                                    aria-disabled="true">WhatsApp</a>
                            </div>
                            <span>Short message goes here...</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="asset/img/user.jpg" alt=""
                            style="width: 40px; height: 40px;">
                        <div class="w-100 ms-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-0">Jhon Doe</h6>
                                <a href="" class="btn btn-success  " role="button" type="button"
                                    aria-disabled="true">WhatsApp</a>
                            </div>
                            <span>Short message goes here...</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="asset/img/user.jpg" alt=""
                            style="width: 40px; height: 40px;">
                        <div class="w-100 ms-3">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-0">Jhon Doe</h6>
                                <a href="" class="btn btn-success  " role="button" type="button"
                                    aria-disabled="true">WhatsApp</a>
                            </div>
                            <span>Short message goes here...</span>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-xl-4">
                <div class="h-100 bg-light rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Calender</h6>
                        <a href="">Show All</a>
                    </div>
                    <div id="calender"></div>
                </div>
            </div>

        </div>
    </div>
    <!-- Widgets End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hosiptal\resources\views/dashboard.blade.php ENDPATH**/ ?>